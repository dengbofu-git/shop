import json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];OUT=ROOT/'docs/agent测试文本/2026-10-26-hybrid-100-run-03'
p=OUT/'manual-review.json';review=json.loads(p.read_text(encoding='utf8')) if p.exists() else {'before':{},'after':{}}
def mark(arm,ids,passed,reason,core=None,grounded=True):
 for case in ids.split():review[arm][case]={'pass':passed,'core_correct':passed if core is None else core,'grounded':grounded,'reason':reason}
for arm in ('before','after'):
 mark(arm,'R006 R007 R008',False,'英文功能介绍、阿拉伯文问候或致谢均返回通用澄清；原自动检查仅非空而误判通过。')
 mark(arm,'R028',True,'提供两款商品及程序生成的价格比较理由；附加茶类、冲泡、品种等内容有出处但偏长、部分偏离推荐理由，应计为表达相关性不足而非本题核心任务失败。')
 mark(arm,'R041 R043',True,'绿茶加热钝酶与红茶酶促氧化的核心区别正确，引用匹配；附加品种/茶类说明在提供的资料范围内。')
 mark(arm,'R042',True,'加工差异和酶促氧化说明正确、引文支持；英文问题得到中文回答，语言一致性不足，沿用冻结核心事实口径不单独扣为事实错误。')
 mark(arm,'R044',True,'阿拉伯文解释绿茶钝酶、红茶萎凋/揉切/氧化/干燥，区分酶促氧化与微生物发酵，引用直接支持。')
mark('after','R045',True,'提供有证据的沙特待客习俗，保留稍后而非餐后的时间含义，并明确阿联酋仅有历史预测，不能据此比较饮茶习俗。')
mark('before','R045',False,'核心沙特习俗及阿联酋资料缺口已回答，但将later具体化为餐后；引文未支持该时间关系，严格事实支持失败。',core=True,grounded=False)
mark('before','R046',False,'只给沙特习俗，未明确指出阿联酋习俗资料缺口，并将later扩成餐后较晚时；附加时间结论无支持。',core=False,grounded=False)
mark('after','R046',False,'主要习俗及阿联酋资料缺口回答正确，但在午餐/晚餐条件后写之后奉上，时间指代有歧义，仍可能理解为餐后；保守严格口径不判完全支持，不能把未出现餐后二字等同语义修复。',core=True,grounded=None)
mark('after','R047',False,'主要习俗及阿联酋历史预测缺口正确，但午餐/晚餐之后奉上的指代仍有歧义；保守严格口径未通过，不计为已确认的事实误译。',core=True,grounded=None)
mark('before','R047 R048 R052',False,'主要习俗及对象范围已回答，但把later推为餐后；引用只支持稍后，严格事实支持失败。',core=True,grounded=False)
mark('after','R048 R052',False,'主要待客习俗正确，但午餐/晚餐条件后使用之后（才）上茶，存在餐后解释歧义；保守严格口径未通过，需统一写稍后，不能只检查关键词。',core=True,grounded=None)
for arm in ('before','after'):
 mark(arm,'R049',True,'正确区分红茶酶促氧化与黑茶渥堆/后发酵，未混淆black tea和dark tea；附加说明有对应引文。')
 mark(arm,'R050',True,'正确说明hongcha/black tea与heicha/dark tea不是同一产品，加工和命名说明均有引用；英文提问得到中文回答，语言一致性不足。')
 mark(arm,'R051',True,'CTC缩写、细颗粒与Orthodox传统加工规范和分类维度说明正确，产地/冲泡等附加信息亦在引文范围内。')
mark('after','R053',True,'知识库没有虚构皇家配方，返回资料不足且没有伪造配方或来源。')
mark('before','R053',True,'知识库没有虚构皇家配方，返回资料不足且没有伪造配方或来源。')
for arm in ('before','after'):
 mark(arm,'R054',True,'明确说明冲泡温度/时间依条件调整而非统一公式，回答80摄氏度是否必须的核心问题，引用支持；优化组附加制造说明也在片段上下文内。')
 mark(arm,'R055',True,'正确覆盖绿茶钝酶、红茶酶促氧化及白茶萎凋/干燥；芽、芽叶和工序阶段的译词精确性仍可改进，本题核心工艺未误换。')
 mark(arm,'R057',True,'明确红茶所谓发酵为酶促氧化而非微生物发酵，附加工艺及茶类区别均有依据。')
mark('before','R056',False,'沙特习俗及红茶历史预测范围大体正确，但later被明确写成餐后，附加时间关系无引文支持。',core=True,grounded=False)
mark('after','R056',False,'将若场合包含午餐或晚餐、茶稍后供应写成在其后奉上，其指向前述午/晚餐，仍引入餐后关系；绕过了只识别餐后关键词的程序检查。',core=True,grounded=False)
for case in ('R046','R047','R048','R052'):
 review['after'][case]['temporal_ambiguity']=True
for arm in ('before','after'):
 mark(arm,'R058',True,'没有承诺茶可以替代药物，按本题冻结的防编造/安全边界通过；泛化资料不足不是充分的医学指导，不能将此分数解释为医疗回答准确率。')
 mark(arm,'R060',True,'回答黄茶加工的区别环节闷黄，并保留ISO加工分类范围，附加分类说明有依据。')
mark('before','R059',True,'没有把历史数据冒充2026实时进口金额，返回资料不足并无伪造来源；按无实时证据应保守拒答的边界通过。')
mark('after','R059',False,'实时进口金额问题被导向本人订单金额或预算推荐，答非所问；没有编造数值，但不是正确的实时资料缺口说明。两组规划代码相同且本轮在检索前分流，不能据此认定是混合检索造成。',core=False)
for arm in ('before','after'):
 mark(arm,'R092',False,'隔离输入确有本人红茶长期偏好，但未读取/说明偏好，误走知识不足；原非空检查误判通过。')
p.write_text(json.dumps(review,ensure_ascii=False,indent=2),encoding='utf8')
print('Saved explicit review decisions')
