import ast, hashlib, json, shutil
from pathlib import Path

ROOT=Path(__file__).resolve().parents[2]; HERE=Path(__file__).resolve().parent
OLD=ROOT/'docs/agent测试文本/2026-10-26-cost-100-run-02'
OUT=ROOT/'docs/agent测试文本/2026-10-26-hybrid-100-run-03'
PRIOR=ROOT/'.scratch/cost-100-ab-20261026'
PRE=ROOT/'.scratch/hybrid-retrieval-20261026/before'
OUT.mkdir(parents=True,exist_ok=False)
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(n,v):(OUT/n).write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
inputs=[]
for package in ROOT.iterdir():
 if package.is_dir() and (package/'__init__.py').exists() and package.name not in ('support_ai','ai_storage'):
  inputs.extend(p for p in package.rglob('*.py') if '__pycache__' not in p.parts)
inputs.append(ROOT/'tea_saas/currency.json')
shared={str(p.relative_to(ROOT)):digest(p) for p in inputs}
for p in inputs:
 target=HERE/'shared'/p.relative_to(ROOT);target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,target)
assert shared=={str(p.relative_to(ROOT)):digest(p) for p in inputs}
for arm in ('before','after'):
 for package in ('support_ai','ai_storage'):
  shutil.copytree(ROOT/package,HERE/arm/package,ignore=shutil.ignore_patterns('__pycache__'))
for name in ('retrieval.py','query_rewrite.py','grounding.py'):
 shutil.copy2(PRE/name,HERE/'before/support_ai'/name)
shutil.copy2(PRE/'knowledge.py',HERE/'before/ai_storage/knowledge.py')
for name in ('cases-100.json','config.json','public-products.json','public-knowledge.json','private-fixtures.json'):
 shutil.copy2(OLD/name,OUT/name)
for arm in ('before','after'):shutil.copy2(ROOT/'.scratch/real100-20261026/fixtures.sqlite3',HERE/(arm+'.sqlite3'))
shutil.copy2(ROOT/'.scratch/real100-20261026/memory.sqlite3',HERE/'memory.sqlite3')
shutil.copy2(PRIOR/'eval_router.py',HERE/'eval_router.py')
settings=(PRIOR/'eval_settings.py').read_text(encoding='utf8')
settings+='\n# Cold-cache primary comparison; identical stage cost policy in both arms.\nSUPPORT_RAG_CACHE_ENABLED=False\nSUPPORT_RAG_REWRITE_CALLS=2 if os.environ.get("EVAL_ARM")=="before" else 1\n'
(HERE/'eval_settings.py').write_text(settings,encoding='utf8')
worker=(PRIOR/'worker.py').read_text(encoding='utf8').replace('2026-10-26-cost-100-run-02','2026-10-26-hybrid-100-run-03')
worker=worker.replace("os.environ['EVAL_DB']=ARM+'.sqlite3';", "os.environ['EVAL_ARM']=ARM;os.environ['EVAL_DB']=ARM+'.sqlite3';")
anchor='retrieval.search_knowledge=public_search'
worker=worker.replace(anchor,anchor+'''
if hasattr(retrieval,'search_knowledge_keywords'):
 real_keyword=retrieval.search_knowledge_keywords
 def public_keyword(query,owner_id,limit=15):
  assert owner_id is None,'Only public keyword knowledge is authorized'
  return real_keyword(query,None,limit=limit)
 retrieval.search_knowledge_keywords=public_keyword
''')
ast.parse(worker);(HERE/'worker.py').write_text(worker,encoding='utf8')
run=(PRIOR/'run.py').read_text(encoding='utf8').replace('2026-10-26-cost-100-run-02','2026-10-26-hybrid-100-run-03')
run=run.replace('before arm reverses only cost-control files','before arm reverses only retrieval changes; same stage cost controls and business rules; application caches disabled')
run=run.replace('p.wait(timeout=30)','p.wait(timeout=60)')
(HERE/'run.py').write_text(run,encoding='utf8');ast.parse(run)
hashes={a:{str(p.relative_to(HERE/a)):digest(p) for package in ('support_ai','ai_storage') for p in (HERE/a/package).rglob('*.py')} for a in ('before','after')}
changed=[p for p,h in hashes['after'].items() if hashes['before'][p]!=h]
assert sorted(p.replace('\\','/') for p in changed)==sorted(['support_ai/retrieval.py','support_ai/query_rewrite.py','support_ai/grounding.py','ai_storage/knowledge.py']),changed
save('source-manifest.json',{'workspace_version':json.loads((ROOT/'versions/modules.json').read_text(encoding='utf8'))['modules']['support_ai']['version'],
 'scope':'Same frozen current business, stage cost policy and migrated PG snapshot; before reverses retrieval changes and restores rewrite cap 2; both application caches disabled',
 'source_sha256':hashes,'shared_source_sha256':shared,'retrieval_change_files':changed,
 'frozen_inputs_sha256':{n:digest(OUT/n) for n in ('cases-100.json','config.json','public-products.json','public-knowledge.json','private-fixtures.json')},
 'fixture_sha256':{n:digest(HERE/n) for n in ('before.sqlite3','after.sqlite3','memory.sqlite3')}})
activation=json.loads((ROOT/'.scratch/hybrid-retrieval-20261026/activation.json').read_text(encoding='utf8'))
activation['backup'].pop('private_local_path',None);save('migration-activation.json',activation)
save('environment.json',dict(json.loads((OLD/'environment.json').read_text(encoding='utf8')),
 cache_policy='disabled for both primary arms; separate warm-cache retrieval-only benchmark',
 stage_policy_scope='same defaults disabled thinking and request/stage budgets in both arms'))
print(json.dumps({'prepared':str(OUT),'cases':100,'changed_files':changed,'shared_files':len(shared)},ensure_ascii=True))
