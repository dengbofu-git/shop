import os, sys, json, hashlib, subprocess
from pathlib import Path
from datetime import datetime, timezone

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'tea_saas.settings')
import django
django.setup()
from django.db import connections
from django.core.management import call_command
from django.db.migrations.executor import MigrationExecutor
from ai_storage.models import KnowledgeDocument, KnowledgeChunk, BuyerMemory

def inventory():
    db = connections['ai_storage']
    with db.cursor() as cursor:
        cursor.execute('SELECT count(*), count(*) FILTER (WHERE status IN (\'queued\',\'running\')) FROM ai_storage_knowledgeimportjob')
        jobs, active = cursor.fetchone()
        cursor.execute("SELECT app, name FROM django_migrations WHERE app='ai_storage' ORDER BY name")
        migrations = cursor.fetchall()
    return {'documents': KnowledgeDocument.objects.count(), 'chunks': KnowledgeChunk.objects.count(),
            'memories': BuyerMemory.objects.count(), 'import_jobs': jobs, 'active_jobs': active,
            'public_documents': KnowledgeDocument.objects.filter(status='published', visibility='public').count(),
            'public_chunks': KnowledgeChunk.objects.filter(document__status='published', document__visibility='public').count(),
            'migrations': migrations}

before = inventory()
assert before['active_jobs'] == 0, 'Active ingestion exists; do not migrate while a job is writing'
plan = MigrationExecutor(connections['ai_storage']).migration_plan([('ai_storage', '0004_hybrid_search')])
assert [(m.app_label, m.name, backwards) for m, backwards in plan] in (
    [], [('ai_storage', '0004_hybrid_search', False)]), 'Unexpected migration scope'
backup = HERE / ('pre-0004-' + datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ') + '.dump')
config = connections['ai_storage'].settings_dict
with backup.open('xb') as handle:
    subprocess.run(['docker', 'exec', 'dadashop-ai-storage-postgres-1', 'pg_dump',
                    '-U', config['USER'], '-d', config['NAME'], '-Fc'], stdout=handle, check=True)
assert backup.stat().st_size > 1000
subprocess.run(['docker', 'exec', '-i', 'dadashop-ai-storage-postgres-1', 'pg_restore', '--list'],
               stdin=backup.open('rb'), stdout=subprocess.DEVNULL, check=True)
call_command('migrate', 'ai_storage', '0004', database='ai_storage', interactive=False, verbosity=1)
after = inventory()
for key in ('documents', 'chunks', 'memories', 'public_documents', 'public_chunks', 'import_jobs'):
    assert before[key] == after[key], (key, before[key], after[key])
with connections['ai_storage'].cursor() as cursor:
    cursor.execute('SELECT count(*) FROM ai_storage_knowledgechunk WHERE search_vector IS NULL OR search_text=\'\'')
    missing = cursor.fetchone()[0]
    cursor.execute("SELECT count(*) FROM pg_indexes WHERE tablename='ai_storage_knowledgechunk' AND indexname='ai_chunk_search_gin'")
    index_count = cursor.fetchone()[0]
assert missing == 0 and index_count == 1
report = {'completed_at': datetime.now(timezone.utc).isoformat(), 'before': before, 'after': after,
          'backup': {'private_local_path': str(backup), 'bytes': backup.stat().st_size,
                     'sha256': hashlib.sha256(backup.read_bytes()).hexdigest(), 'archive_list_verified': True},
          'missing_search_index_rows': missing, 'gin_index_count': index_count,
          'business_mysql_changed': False, 'services_restarted': False}
(HERE/'activation.json').write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf8')
print(json.dumps(report, ensure_ascii=True))
connections.close_all()
