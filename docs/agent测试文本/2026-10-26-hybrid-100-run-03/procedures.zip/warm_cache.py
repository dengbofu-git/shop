import os, sys, json, time, hashlib
from pathlib import Path
from dataclasses import replace
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1];OUT=ROOT/'docs/agent测试文本/2026-10-26-hybrid-100-run-03'
from dotenv import load_dotenv
load_dotenv(ROOT/'.env',override=False);load_dotenv(ROOT/'.env.postgres',override=False)
os.environ.update(DJANGO_SETTINGS_MODULE='eval_settings',EVAL_ARM='after',EVAL_DB='after.sqlite3')
sys.path[:0]=[str(HERE/'after'),str(HERE),str(HERE/'shared'),str(ROOT)]
import django;django.setup()
from django.test import override_settings
from django.db import connections
from django.core.cache import cache
from ai_storage.models import KnowledgeChunk
from support_ai.configuration import AgentConfig
from support_ai.retrieval import KnowledgeRetriever
import requests
records=[];active=[];original_send=requests.Session.send
def send(client,request,**kw):
 start=time.perf_counter();row={'service':'rerank' if 'rerank' in request.url else 'embedding'}
 try:
  response=original_send(client,request,**kw);row['http_status']=response.status_code;return response
 except Exception as exc:row['error_type']=type(exc).__name__;raise
 finally:row['seconds']=time.perf_counter()-start;active.append(row)
requests.Session.send=send
def corpus():
 rows=list(KnowledgeChunk.objects.filter(document__visibility='public',document__status='published',embedding__isnull=False).order_by('pk').values_list('pk','text'))
 return hashlib.sha256(json.dumps(rows,ensure_ascii=False).encode('utf8')).hexdigest()
with connections['ai_storage'].cursor() as cursor:cursor.execute('SET default_transaction_read_only=on')
before=corpus();assert before==json.loads((OUT/'run-state.json').read_text(encoding='utf8'))['postgresql']['public_corpus_sha256']
config=replace(AgentConfig(**json.loads((OUT/'config.json').read_text(encoding='utf8'))),telemetry_enabled=False,export_enabled=False)
def prohibited_model():raise RuntimeError('No generation/translation API calls authorized in retrieval-only cache benchmark')
questions=['Black tea manufacturing process','Green tea manufacturing process','Saudi Arabia tea drinking customs','White tea manufacturing process','Oxidation and fermentation in tea processing']
with override_settings(SUPPORT_RAG_CACHE_ENABLED=True,SUPPORT_RAG_REWRITE_CALLS=0):
 for query in questions:
  cache.clear()  # Only this isolated process's LocMemCache, never shared Redis.
  for round_number in range(3):
   active=[];start=time.perf_counter();cpu=time.process_time();retriever=KnowledgeRetriever(None,config,model_factory=prohibited_model)
   evidence=retriever.search(query)
   records.append({'query':query,'round':round_number,'seconds':time.perf_counter()-start,'client_cpu_seconds':time.process_time()-cpu,
                   'selected_ids':[r['chunk_id'] for r in evidence],'audit':retriever.audit,'local_calls':active})
   print(json.dumps({'round':round_number,'seconds':records[-1]['seconds'],'cache':retriever.audit[-1].get('cache_status')}),flush=True)
after=corpus();assert before==after
(OUT/'warm-cache.json').write_text(json.dumps({'scope':'retrieval-only; 5 public questions x cold + two warm attempts; no generation; rewrite disabled; isolated LocMemCache; no primary-result replacement',
 'public_corpus_sha256':before,'corpus_unchanged':before==after,'records':records},ensure_ascii=False,indent=2),encoding='utf8')
connections.close_all()
