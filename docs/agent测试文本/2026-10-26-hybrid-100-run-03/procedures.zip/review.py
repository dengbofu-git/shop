import json, sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];OUT=ROOT/'docs/agent测试文本/2026-10-26-hybrid-100-run-03'
start=int(sys.argv[1]);end=int(sys.argv[2]);parts=[]
for arm in ('before','after'):
 parts.append('\n# '+arm)
 for line in (OUT/(arm+'-results.jsonl')).read_text(encoding='utf8').splitlines():
  r=json.loads(line)
  if start<=int(r['id'][1:])<=end:
   parts.append('\n## '+r['id']+' '+r['message']+' ['+r['status']+']\n'+r.get('response',{}).get('answer','ERROR '+r.get('error_type','')))
   if start>=41 and end<=60:
    parts.append('Quotes: '+json.dumps([{'text':v.get('text'),'citations':v.get('citations')} for k in r.get('response',{}).get('grounding',{}).get('knowledge',[]) for v in k.get('claims',[])],ensure_ascii=False))
text='\n'.join(parts)
(OUT/'review-working.txt').write_text(text,encoding='utf8')
print(text)
