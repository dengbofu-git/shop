import json,hashlib,zipfile,statistics
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent;OUT=ROOT/'docs/agent测试文本/2026-10-26-hybrid-100-run-03'
def load(n):return json.loads((OUT/n).read_text(encoding='utf8'))
def save(n,v):(OUT/n).write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
s=load('summary.json');b=s['before'];a=s['after'];rag=load('retrieval-quality.json');review=load('manual-review.json')
reduce=lambda new,old:100*(1-new/old) if old else 0
fee=lambda row:'$%.6f–$%.6f'%(row['usage']['cost_usd_offpeak'],row['usage']['cost_usd_peak'])
manifest=load('source-manifest.json');drift=[]
for rel,h in manifest['source_sha256']['after'].items():
 p=ROOT/rel
 if not p.exists() or hashlib.sha256(p.read_bytes()).hexdigest()!=h:drift.append(rel)
save('workspace-drift.json',{'frozen_workspace_version':manifest['workspace_version'],'post_run_workspace_version':json.loads((ROOT/'versions/modules.json').read_text(encoding='utf8'))['modules']['support_ai']['version'],
 'changed_source_files_since_freeze':drift,'scope':'Only frozen source defines tested code; unrelated later changes are not validated'})
k={}
for arm in ('before','after'):
 entries=[review[arm]['R%03d'%i] for i in range(41,61)]
 k[arm]={'reviewed':20,'core_correct':sum(v.get('core_correct',v['pass']) for v in entries),'strict_pass':sum(v['pass'] for v in entries),
 'unsupported_claim_cases':sum(v.get('grounded') is False for v in entries),'temporal_ambiguity_cases':sum(v.get('temporal_ambiguity',False) for v in entries)}
save('knowledge-review-summary.json',k)
activation=load('migration-activation.json');warm=load('warm-cache.json') if (OUT/'warm-cache.json').exists() else None
report=['# 同题100条：混合检索改进前后真实评测','',
 '本轮两组各100条实际执行；相同冻结业务代码、相同阶段thinking/Token成本策略，只撤回或启用检索改进。主对照关闭应用缓存，另列公开知识检索缓存微基准。','',
 '**结果对应冻结源码版本'+manifest['workspace_version']+'；运行期间另有'+str(len(drift))+'个源文件变化，未纳入本轮。相同版本号不代表相同源码，以指纹为准。**','',
 '## 结果','', '| 指标 | 改进前 | 改进后 |','|---|---:|---:|',
 '| 自动约束通过 | %d/100 | %d/100 |'%(b['automatic_pass'],a['automatic_pass']),
 '| 重点复核修正后的通过 | %d/100 | %d/100 |'%(b['reviewed_pass'],a['reviewed_pass']),
 '| 平均耗时 | %.3fs | %.3fs |'%(b['latency_seconds']['mean'],a['latency_seconds']['mean']),
 '| P50耗时 | %.3fs | %.3fs |'%(b['latency_seconds']['p50'],a['latency_seconds']['p50']),
 '| P95耗时 | %.3fs | %.3fs |'%(b['latency_seconds']['p95'],a['latency_seconds']['p95']),
 '| 模型请求 | %d | %d |'%(b['usage']['calls'],a['usage']['calls']),
 '| 查询改写调用 | %d | %d |'%(b['retrieval']['rewrite_calls'],a['retrieval']['rewrite_calls']),
 '| 输入Token | %d | %d |'%(b['usage']['input_tokens'],a['usage']['input_tokens']),
 '| 输出Token | %d | %d |'%(b['usage']['output_tokens'],a['usage']['output_tokens']),
 '| 其中思考Token | %d | %d |'%(b['usage']['reasoning_tokens'],a['usage']['reasoning_tokens']),
 '| 已知usage费用USD | %s | %s |'%(fee(b),fee(a)),
 '| 未返回usage调用 | %d | %d |'%(b['usage']['missing_usage'],a['usage']['missing_usage']),'',
 '同价已知用量费用减少%.1f%%，平均耗时减少%.1f%%，P95减少%.1f%%。负数表示增加。每题每组仅一次，不能据此声称统计显著或线上准确率。'%(reduce(a['usage']['cost_usd_peak'],b['usage']['cost_usd_peak']),reduce(a['latency_seconds']['mean'],b['latency_seconds']['mean']),reduce(a['latency_seconds']['p95'],b['latency_seconds']['p95'])),'',
 '## 质量复核','',
 '知识20题全部逐项复核；另外复核语言入口、推荐理由和偏好读取等已知自动检查薄弱项。其他题沿用相同冻结自动约束；这不是全200条独立专家盲审。','',
 '| 知识专项20题 | 前 | 后 |','|---|---:|---:|',
 '| 核心任务完成 | %d/20 | %d/20 |'%(k['before']['core_correct'],k['after']['core_correct']),
 '| 核心及附加事实均通过 | %d/20 | %d/20 |'%(k['before']['strict_pass'],k['after']['strict_pass']),
 '| 含无支持附加事实的题数 | %d | %d |'%(k['before']['unsupported_claim_cases'],k['after']['unsupported_claim_cases']),
 '| 时间指代仍有歧义的题数 | %d | %d |'%(k['before']['temporal_ambiguity_cases'],k['after']['temporal_ambiguity_cases']),'',
 '严格口径把R046/R047/R048/R052新组的“之后”指代歧义也保守计为未通过，grounded=null，不把它们当成已经证实的错误事实；旧组6题明确写餐后，新组R056“其后”仍引入餐后关系。若仅为敏感性观察而不扣4条歧义，新组为76/100、知识18/20；主统计仍保留72/100、14/20。不是事先注册的专家盲审，不能把词面不含餐后等同于语义正确。','',
 '改善：'+('、'.join(s['paired_changes']['improved']) or '无')+'；回退：'+('、'.join(s['paired_changes']['regressed']) or '无')+'。完整理由见manual-review.json、paired-changes.json和逐条实际记录.md。','',
 '## 分场景','', '| 场景 | 前/后通过 | 前/后平均耗时 | 前/后已知峰时费用USD |','|---|---:|---:|---:|']
for group in b['groups']:
 x=b['groups'][group];y=a['groups'][group]
 report.append('| %s | %d/%d → %d/%d | %.3f / %.3fs | $%.6f / $%.6f |'%(group,x['reviewed_pass'],x['count'],y['reviewed_pass'],y['count'],x['latency_seconds']['mean'],y['latency_seconds']['mean'],x['usage']['cost_usd_peak'],y['usage']['cost_usd_peak']))
report+=['','## 检索相关性','', '| 固定15题预标注子集 | 前 | 后 |','|---|---:|---:|',
 '| 最终片段直接相关精度 | %.4f | %.4f |'%(rag['before']['mean_precision'],rag['after']['mean_precision']),
 '| 支持点覆盖 | %.4f | %.4f |'%(rag['before']['mean_coverage'],rag['after']['mean_coverage']),
 '| nDCG@5 | %.4f | %.4f |'%(rag['before']['mean_ndcg_at_5'],rag['after']['mean_ndcg_at_5']),'',
 '沿用原15题、原chunk ID相关性标注及支持组；无支持组的虚构配方题不计覆盖/nDCG均值。指标使用本轮最终所选片段，复合问题跨任务结果按首次出现顺序去重，不是独立检索器大规模标准榜。候选范围、融合、上下文和核验共同变化，不能归因于其中单独一个开关。','',
 '13题最终片段列表完全相同；R053虚构配方题和R054冲泡题替换了末位片段，但未改变这套标注下的相关性指标。本轮没有证据表明混合检索在该50片段小库上提高相关性。','',
 '## 分阶段开销','', '| 结构化阶段 | 前/后调用 | 前/后已知峰时费用USD |','|---|---:|---:|']
for name in dict.fromkeys([*b['schemas'],*a['schemas']]):
 x=b['schemas'].get(name,{});y=a['schemas'].get(name,{})
 report.append('| %s | %d / %d | $%.6f / $%.6f |'%(name,x.get('calls',0),y.get('calls',0),x.get('cost_usd_peak',0),y.get('cost_usd_peak',0)))
report+=['','## 本地服务及缓存','', '| 服务 | 前/后实际请求数 | 前状态 | 后状态 |','|---|---:|---|---|']
for service in ('embedding','rerank'):
 x=b['local'][service];y=a['local'][service]
 report.append('| %s | %d / %d | %s | %s |'%(service,x['calls'],y['calls'],json.dumps(x['http_statuses']),json.dumps(y['http_statuses'])))
if warm:
 cold=[r for r in warm['records'] if r['round']==0];hits=[r for r in warm['records'] if r['round']>0 and r['audit'][-1].get('cache_status')=='hit']
 report+=['','单独的缓存微基准：5个公开知识问题，各执行一次冷查询及两次热尝试；只测检索，不做答案生成，禁用模型改写，使用本进程独立LocMemCache。',
   '冷查询平均%.4fs；10次热尝试中%d次命中，实际命中平均%s。冷指应用缓存为空，不代表模型/GPU冷启动。不能将检索缓存耗时当成完整Agent回答耗时或100题整体降费比例。'%(statistics.mean(r['seconds'] for r in cold),len(hits),'%.4fs'%statistics.mean(r['seconds'] for r in hits) if hits else '无命中'),
 '没有命中的热尝试及全部实际本地调用保留在warm-cache.json，不以重试替换。']
report+=['','## 数据库启用','',
 'ai_storage.0004_hybrid_search已实际应用。迁移前生成私有pg_dump备份（%d字节，SHA256 %s）并通过pg_restore目录读取检查；未在业务库试恢复。'%(activation['backup']['bytes'],activation['backup']['sha256']),
 '迁移前后文档%d、片段%d、长期记忆%d数量一致；公开已发布文档%d、片段%d。全文索引缺失行%d，GIN索引%d个。未修改MySQL、未回退数据库、未重启服务。'%(activation['after']['documents'],activation['after']['chunks'],activation['after']['memories'],activation['after']['public_documents'],activation['after']['public_chunks'],activation['missing_search_index_rows'],activation['gin_index_count']),'',
 '## 控制变量、费用和边界','',
 '- 两组各100条，固定问题/115个公开SKU快照/27笔合成订单/专用偏好fixture，AB/BA交替顺序执行。真实用户订单和偏好未发给模型。',
 '- 冻结当前support_ai、ai_storage和共享Django依赖源码；两组仅4个检索相关源文件不同，对照恢复旧检索/改写/核验代码及改写上限2，优化组上限1。保留相同当前业务及模型成本控制。',
 '- 同一PostgreSQL REPEATABLE READ READ ONLY共享快照，仅owner=None公开已发布知识；原50片段正文hash与上一轮一致。主评测应用缓存明确关闭，因此不是靠缓存省掉模型请求。',
 '- DeepSeek真实调用，模型deepseek-flash，实际HTTP thinking、max_tokens、schema、usage逐次记录。零隐藏SDK重试；超时/错误不删除、不自动重跑换分。',
 '- 客服图/工具集成评测，业务数据由隔离SQLite提供；不是HTTP认证、幂等重放、浏览器、业务MySQL吞吐或独占硬件压测。',
 '- 费用按实际usage分别计算缓存命中/未命中输入及输出，非峰时每百万Token USD 0.003/0.15/0.6，峰时双倍；范围是两种同价口径，不是账单区间。有缺失usage时未知实扣不在表内。本地CPU/GPU、内存和电费未折算货币。来源：[DeepSeek官方价格](https://api-docs.deepseek.com/quick_start/pricing/)。',
 '- 模型平台缓存跨组共享，AB/BA仅降低顺序偏差；真实服务负载、超时及生成随机性仍可能影响差异。没有把故障或少回答自动解释为成功降费。',
 '- 旧成本报告含不同业务快照，只作历史参考，不把其差异归因于本次检索。未提交、推送或创建PR。',
 '- 冻结后源文件漂移%d个；具体见workspace-drift.json；原输入/源码/调用记录完整性见integrity.json。'%len(drift),'']
extra=['## 为什么调用明显减少，费用只减少4.3%','',
 '模型调用136→108、改写34→9，但生成输出总量下降有限。两组提示与片段组合有差异，实际usage显示供应商缓存命中情况也不同：全局未命中输入48691→55960，知识草稿费用由非峰时$0.006929升至$0.008506，核验由$0.004563升至$0.005016，抵消了改写的节省。不能单独证实新提示是缓存差异的全部原因。',
 '应用检索缓存与DeepSeek供应商提示缓存是两回事；主对照关闭前者，后者是平台实际usage的一部分。即便把全部输入都按未命中费率作反事实估算，本样本也仅约降7.0%，不是大幅降费承诺。','',
 '全100题主结果含R059错误分流造成的少调用，不能将该部分解释为成功降费。事后选择两组都完成核心任务的18道知识题：模型调用64→46，平均15.443→13.494秒，已知费用仅下降约1.4%；两组都严格通过的13题费用仅下降约0.7%。详细为knowledge-common.json，后验子集不替代主统计。','',
 '## 回退与剩余问题','',
 '- R025：每款不超过10美元仍被追加单价/总价澄清；R063：继承预算的红茶追问被安全校验拒绝；R059：实时进口数据问题被误分流至订单/预算。三条新组均未调用检索，两组对应规划代码相同，不能从单次配对认定它们由新检索造成；仍保留在端到端失败统计，不剔除。',
 '- R045为明确改善，其他时间题仍有其后或之后的问题。严格知识通过14/20→14/20，尚不能宣称精度提高；不能把同一个时间误译模式的多题当成多类独立改进。',
 '- R029—R034完整商品名称定位、R075订单分页、R090无绑定指定订单、R092本人偏好读取等问题继续存在；R100两组均未给推荐，但实际外发请求未含测试手机号/邮箱，推荐任务失败与隐私边界通过应分开看。',
 '- 本地嵌入173次请求均HTTP 200；对照重排1次ReadTimeout，新组30次重排均HTTP 200。单次重排平均并未更快（6.026→6.244秒），收益主要来自调用减少，不能把候选上限直接当作单次性能改善的证据。','',
 '本次结论：迁移与检索功能已启用，调用和平均延迟下降；API降费幅度小，预标注检索相关性未提高，端到端及时间含义仍有问题。应先修复规划/时间语义稳定性并扩大独立检索标注集，再判断默认混合检索的收益。','']
position=report.index('## 质量复核');report[position:position]=extra
(OUT/'测试报告.md').write_text('\n'.join(report),encoding='utf8')
with zipfile.ZipFile(OUT/'procedures.zip','w',zipfile.ZIP_DEFLATED) as archive:
 for p in HERE.rglob('*'):
  if p.is_file() and p.suffix in ('.py','.json') and '__pycache__' not in p.parts:archive.write(p,str(p.relative_to(HERE)))
 archive.write(ROOT/'.scratch/hybrid-retrieval-20261026/activate.py','activation/activate.py')
save('file-sha256.json',{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in OUT.iterdir() if p.is_file() and p.name not in ('file-sha256.json','review-working.txt')})
print(json.dumps({'report':str(OUT/'测试报告.md'),'before_reviewed':b['reviewed_pass'],'after_reviewed':a['reviewed_pass'],'cost_reduction_pct':reduce(a['usage']['cost_usd_peak'],b['usage']['cost_usd_peak'])},ensure_ascii=True))
