import os, sys, json, platform, importlib.metadata
from pathlib import Path
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1];OUT=ROOT/'docs/agent测试文本/2026-10-26-hybrid-100-run-03'
from dotenv import load_dotenv
load_dotenv(ROOT/'.env',override=False);load_dotenv(ROOT/'.env.postgres',override=False)
os.environ.update(DJANGO_SETTINGS_MODULE='eval_settings',EVAL_ARM='after',EVAL_DB='after.sqlite3')
sys.path[:0]=[str(HERE/'after'),str(HERE),str(HERE/'shared'),str(ROOT)]
import django;django.setup()
from support_ai.cost_control import RequestBudget
data=json.loads((OUT/'environment.json').read_text(encoding='utf8'))
data.update(python=sys.version,platform=platform.platform(),packages={name:importlib.metadata.version(name) for name in
 ['Django','openai','langchain-core','langchain-openai','langgraph','pydantic','httpx','requests','pgvector']},
 after_policy=RequestBudget().snapshot())
data['pricing']['checked_date']='2026-10-26'
(OUT/'environment.json').write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf8')
print(json.dumps({'stage_policy':data['after_policy']['stage_policy'],'no_provider_calls':True}))
