import hashlib, json, math, statistics, zipfile
from collections import Counter
from pathlib import Path

HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1];OUT=ROOT/'docs/agent测试文本/2026-10-26-hybrid-100-run-03'
def load(n):return json.loads((OUT/n).read_text(encoding='utf8'))
def lines(n):return [json.loads(s) for s in (OUT/n).read_text(encoding='utf8').splitlines()]
def save(n,v):(OUT/n).write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
def pct(v,p):
 v=sorted(v);x=(len(v)-1)*p;i=int(x);return v[i]+(v[min(i+1,len(v)-1)]-v[i])*(x-i)
def stats(v):return {'mean':statistics.mean(v),'p50':pct(v,.5),'p95':pct(v,.95),'max':max(v)} if v else None
def usage(calls):
 s=dict(calls=len(calls),input_tokens=0,output_tokens=0,reasoning_tokens=0,cache_hit_tokens=0,cache_miss_tokens=0,missing_usage=0)
 for c in calls:
  u=c.get('usage',{});s['missing_usage']+=not bool(u)
  s['input_tokens']+=u.get('prompt_tokens',0);s['output_tokens']+=u.get('completion_tokens',0)
  s['reasoning_tokens']+=(u.get('completion_tokens_details') or {}).get('reasoning_tokens',0)
  hit=u.get('prompt_cache_hit_tokens',(u.get('prompt_tokens_details') or {}).get('cached_tokens',0))
  s['cache_hit_tokens']+=hit;s['cache_miss_tokens']+=u.get('prompt_cache_miss_tokens',u.get('prompt_tokens',0)-hit)
 s['cost_usd_offpeak']=(s['cache_hit_tokens']*.003+s['cache_miss_tokens']*.15+s['output_tokens']*.6)/1e6
 s['cost_usd_peak']=s['cost_usd_offpeak']*2
 return s

cases=load('cases-100.json');arms=['before','after'];rows={a:lines(a+'-results.jsonl') for a in arms}
assert all(len(rs)==100 and [r['id'] for r in rs]==['R%03d'%i for i in range(1,101)] for rs in rows.values())
review=load('manual-review.json') if (OUT/'manual-review.json').exists() else {}
def verdict(a,r):return review.get(a,{}).get(r['id'],{}).get('pass',r['status']=='passed')
summary={}
for a,rs in rows.items():
 calls=[c for r in rs for c in r['api']];local=[c for r in rs for c in r['local']]
 summary[a]={'total':100,'automatic_pass':sum(r['status']=='passed' for r in rs),'reviewed_pass':sum(verdict(a,r) for r in rs),
 'review_entries':len(review.get(a,{})),'uncaught_errors':sum(r['status']=='error' for r in rs),'usage':usage(calls),
 'latency_seconds':stats([r['duration_seconds'] for r in rs]),'model_path_latency':stats([r['duration_seconds'] for r in rs if r['api']]),
 'groups':{},'schemas':{},'local':{},'http_statuses':dict(Counter(str(c.get('http_status',c.get('error_type'))) for c in calls)),
 'sensitive_prompt_hits':[c['case_id'] for c in calls if c.get('sensitive_input_hits')],
 'max_calls_per_turn':max(len(r['api']) for r in rs),
 'retrieval':{'queries':sum(len(q.get('queries',[])) for r in rs for q in r['retrieval']),
 'keyword_routes':sum(q.get('channel')=='keyword' for r in rs for audit in r['retrieval'] for q in audit.get('queries',[])),
 'cache_hits':sum(q.get('cache_status')=='hit' for r in rs for q in r['retrieval']),
 'rewrite_calls':sum(c.get('schema')=='QueryTranslations' for c in calls)}}
 for group in dict.fromkeys(c['group'] for c in cases):
  selected=[r for r in rs if r['group']==group]
  summary[a]['groups'][group]={'count':len(selected),'automatic_pass':sum(r['status']=='passed' for r in selected),
  'reviewed_pass':sum(verdict(a,r) for r in selected),'latency_seconds':stats([r['duration_seconds'] for r in selected]),
  'usage':usage([c for r in selected for c in r['api']])}
 for name in dict.fromkeys(c.get('schema') or 'unknown' for c in calls):summary[a]['schemas'][name]=usage([c for c in calls if (c.get('schema') or 'unknown')==name])
 for service in ('embedding','rerank'):
  selected=[c for c in local if c['service']==service]
  summary[a]['local'][service]={'calls':len(selected),'http_statuses':dict(Counter(str(c.get('http_status',c.get('error_type'))) for c in selected)),'latency_seconds':stats([c['seconds'] for c in selected])}
pairs=[]
for b,a in zip(rows['before'],rows['after']):
 pairs.append({'id':b['id'],'before_pass':verdict('before',b),'after_pass':verdict('after',a),
 'before_seconds':b['duration_seconds'],'after_seconds':a['duration_seconds'],
 'before_peak_usd':usage(b['api'])['cost_usd_peak'],'after_peak_usd':usage(a['api'])['cost_usd_peak']})
summary['paired_changes']={'improved':[p['id'] for p in pairs if p['after_pass'] and not p['before_pass']],
 'regressed':[p['id'] for p in pairs if p['before_pass'] and not p['after_pass']],
 'same_pass':sum(p['before_pass'] and p['after_pass'] for p in pairs),'same_fail':sum(not p['before_pass'] and not p['after_pass'] for p in pairs)}
save('summary.json',summary);save('paired-changes.json',pairs)
common={}
for name,field in [('common_core','core_correct'),('common_strict','pass')]:
 ids=['R%03d'%i for i in range(41,61) if all(review.get(a,{}).get('R%03d'%i,{}).get(field,False) for a in arms)]
 common[name]={'ids':ids,'count':len(ids),'scope':'Post-hoc common-success sensitivity, not a replacement for all-100 primary result'}
 for arm in arms:
  selected=[r for r in rows[arm] if r['id'] in ids]
  common[name][arm]={'usage':usage([c for r in selected for c in r['api']]),'latency_seconds':stats([r['duration_seconds'] for r in selected])}
save('knowledge-common.json',common)
labels=json.loads((ROOT/'reports/agent-evaluation/2026-10-26-rerank-query-ab/run-2/cases.json').read_text(encoding='utf8'));rag={}
for arm,rs in rows.items():
 records=[]
 for c,label in zip(cases[40:55],labels):
  r=next(x for x in rs if x['id']==c['id']);ids=list(dict.fromkeys(int(v) for q in r['retrieval'] for v in q.get('selected_ids',[])))
  relevant=set(label['relevant_ids']);groups=label['support_groups'];grades=label['grades']
  dcg=lambda values:sum((2**g-1)/math.log2(i+2) for i,g in enumerate(values))
  ideal=dcg(sorted(grades.values(),reverse=True)[:5])
  records.append({'id':c['id'],'selected_ids':ids,'precision':len(set(ids)&relevant)/len(ids) if ids else 0,
   'coverage':sum(bool(set(g)&set(ids)) for g in groups)/len(groups) if groups else None,
   'ndcg_at_5':dcg([grades.get(str(v),0) for v in ids[:5]])/ideal if ideal else None})
 rag[arm]={'mean_precision':statistics.mean(r['precision'] for r in records),'mean_coverage':statistics.mean(r['coverage'] for r in records if r['coverage'] is not None),
 'mean_ndcg_at_5':statistics.mean(r['ndcg_at_5'] for r in records if r['ndcg_at_5'] is not None),'cases':records}
save('retrieval-quality.json',rag)
detail=['# 同题100条混合检索前后实际记录','','两组均为本轮实际执行，同业务与模型成本策略；主对照禁用应用缓存。','']
for c in cases:
 detail+=['## '+c['id']+' · '+c['group'],'',c['message'],'','预期：`'+json.dumps(c['checks'],ensure_ascii=False)+'`','']
 for arm,label in [('before','改进前'),('after','改进后')]:
  r=next(x for x in rows[arm] if x['id']==c['id']);u=usage(r['api']);rv=review.get(arm,{}).get(c['id'])
  detail+=['### '+label+'：'+('通过' if verdict(arm,r) else '未通过'),'',r.get('response',{}).get('answer','运行异常：'+r.get('error_type','unknown')),'',
   '耗时%.3fs；模型调用%d次；输入/输出Token %d/%d；已知用量USD $%.6f–$%.6f。'%(r['duration_seconds'],u['calls'],u['input_tokens'],u['output_tokens'],u['cost_usd_offpeak'],u['cost_usd_peak']),
   '','自动检查：`'+json.dumps(r['checks'],ensure_ascii=False)+'`','']
  if rv:detail+=['复核：'+rv['reason'],'']
(OUT/'逐条实际记录.md').write_text('\n'.join(detail),encoding='utf8')
manifest=load('source-manifest.json')
digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
integrity={'records':{a:len(rs) for a,rs in rows.items()},'frozen_sources_unchanged':{a:all(digest(HERE/a/k)==h for k,h in manifest['source_sha256'][a].items()) for a in arms},
 'shared_sources_unchanged':all(digest(HERE/'shared'/k)==h for k,h in manifest['shared_source_sha256'].items()),
 'inputs_unchanged':all(digest(OUT/k)==h for k,h in manifest['frozen_inputs_sha256'].items()),
 'fixture_unchanged':{n:digest(HERE/n)==h for n,h in manifest['fixture_sha256'].items()},
 'api_log_calls':len(lines('api-calls.jsonl')),'row_api_calls':sum(len(r['api']) for rs in rows.values() for r in rs)}
assert all(integrity['frozen_sources_unchanged'].values()) and integrity['shared_sources_unchanged'] and integrity['inputs_unchanged'] and all(integrity['fixture_unchanged'].values())
assert integrity['api_log_calls']==integrity['row_api_calls']
public_ids={int(v['id']) for v in load('public-knowledge.json')}
integrity['public_evidence_only']=all(int(v) in public_ids for rs in rows.values() for r in rs for q in r['retrieval'] for v in q.get('selected_ids',[]))
ids=[c.get('response_id') for rs in rows.values() for r in rs for c in r['api'] if c.get('response_id')]
integrity['unique_provider_response_ids']=len(ids)==len(set(ids))
integrity['sensitive_prompt_hits']=sum(bool(c.get('sensitive_input_hits')) for rs in rows.values() for r in rs for c in r['api'])
assert integrity['public_evidence_only'] and integrity['unique_provider_response_ids'] and integrity['sensitive_prompt_hits']==0
save('integrity.json',integrity)
print(json.dumps({'summary':summary,'rag':{a:{k:v for k,v in vals.items() if k!='cases'} for a,vals in rag.items()}},ensure_ascii=True))
