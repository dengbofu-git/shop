# -*- coding: utf-8 -*-
import json,sqlite3,hashlib,zipfile
from pathlib import Path
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1];OUT=ROOT/'docs/agent测试文本/2026-10-26-real-100-run-01'
def load(n):return json.loads((OUT/n).read_text(encoding='utf8'))
def save(n,v):(OUT/n).write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
s=load('summary.json');old=s['baseline'];new=s['current'];pct=lambda a,b:100*(a/b-1)
intro=(f"\n## 本次主要结论\n\n"
 f"- 按当前业务要求验收，复核后当前版69/100、旧版62/100；提升主要来自订单查询新增能力。排除预算/币种/订单变更影响的70条共同场景，当前版46/70（65.7%），旧版50/70（71.4%），不能据总分称新版全面更好。\n"
 f"- 当前版平均耗时比旧版增加{pct(new['latency_seconds']['mean'],old['latency_seconds']['mean']):.1f}%，P95增加{pct(new['latency_seconds']['p95'],old['latency_seconds']['p95']):.1f}%；已回传usage的API费用同价口径增加{pct(new['usage']['cost_usd_peak'],old['usage']['cost_usd_peak']):.1f}%。模型调用总数194对203反而略少，主要开销来自输出/思考Token：237887对125042；思考Token为206627对92279。\n"
 "- 20条知识问题逐条复核：核心任务完成当前15/20、旧19/20；若再要求附加事实也准确，当前15/20、旧13/20。旧版有6条附加事实超出证据或误译；当前版少了这类错误，但存在过度拒答、遗漏部分问题及误拦截。这里不是独立专家准确率。\n"
 "- 15条预标注知识题中，当前最终证据覆盖率与nDCG@5较高，但相关精度没有提高；服务还出现429/超时，不能将结果解释为单独重排策略的干净消融结论。\n"
 "- 当前版优先问题：新请求的单价/总价意图混淆（R015/R016/R025/R071/R091/R093）；真实商品名与规格定位失败（R029–R034）；分页续查失败（R075）；未绑定订单时错误退回最近三笔（R090）；本人已保存偏好问答缺失（R092）；知识/推荐答复被不相关的订单安全提示覆盖（R028/R054）。\n"
 "- 建议先修意图路由、槽位传递和按任务降级，再限制知识核验的调用/思考预算并做定向复测；本次只评测，未修这些业务问题。\n")
detail=['\n## 分路径和分场景性能\n','| 口径 | 旧版 | 当前版 |','|---|---:|---:|']
for key,label in [('rule_path_latency_seconds','规则路径平均耗时'),('model_path_latency_seconds','发生模型调用的轮次平均耗时'),('common_latency_seconds','70条共同规则子集平均耗时')]:detail.append('| '+label+' | %.3fs | %.3fs |'%(old[key]['mean'],new[key]['mean']))
detail+=['','| 场景 | 旧版平均耗时 | 当前版平均耗时 | 旧/新API调用次数 |','|---|---:|---:|---:|']
for g in new['groups']:
 a=old['groups'][g];b=new['groups'][g];detail.append('| '+g+' | %.3fs | %.3fs | %s / %s |'%(a['latency_seconds']['mean'],b['latency_seconds']['mean'],a['usage']['calls'],b['usage']['calls']))
detail+=['','## 服务异常与比较限制','', '本地重排：旧版33次请求中27次HTTP 200、5次429、1次客户端ReadTimeout；当前31次请求中23次200、7次429、1次客户端ReadTimeout。嵌入：旧版117次200；当前108次200、2次ReadTimeout。原代码按配置降级，所有实际结果保留；未停止或修改共享服务，也未隔离其他本机负载。此次吞吐/延迟不是独占硬件微基准。','', 'DeepSeek模型调用缺失usage：旧版1次、当前3次，均在原始日志保留。费用表只覆盖已知usage；总账单实扣还可能包含这些超时请求的费用。调用级费用无本地硬件、用电或人工成本。','', '人工复核：知识专项两版各20条全覆盖；另复核了多语言入口、异常答复、偏好和旧版订单字段差异等重点条目。其余沿用冻结自动约束；不是200条独立专家全文盲审。旧版R078–R081因缺少新版order_result字段被自动误判，人工按实际单笔状态与工具结果纠正；R084隐藏订单漏检则纠正为失败。','', '除5条长期偏好专项外，图的长期记忆输入显式为None；不覆盖HTTP入口统一记忆读取、写回或PostgreSQL长期记忆性能。故障恢复是图层注入知识工具超时后保留模拟上下文的下一轮，不覆盖HTTP 503后的提交/回放、MySQL断线或真实服务重启恢复。','']
p=OUT/'测试报告.md';text=p.read_text(encoding='utf8');text=text.replace('\n## 口径与边界',intro+'\n## 口径与边界',1);text=text.replace('\n## 失败与复核','\n'.join(detail)+'\n## 失败与复核',1);text=text.replace('费用部分，缓存命中/未命中分别计价','已知用量中的缓存命中/未命中分别计价');p.write_text(text,encoding='utf8')
integrity=load('integrity.json');checks={}
for arm in ['baseline','current']:
 connection=sqlite3.connect('file:'+str(HERE/(arm+'.sqlite3'))+'?mode=ro',uri=True)
 counts={table:connection.execute('SELECT COUNT(*) FROM '+table).fetchone()[0] for table in ['goods_sku','orders_order_info','support_ai_supportturn']}
 orders=connection.execute('SELECT order_id,status,buyer_hidden FROM orders_order_info ORDER BY order_id').fetchall();checks[arm]={'counts':counts,'order_states_match':all(status==int(oid[-4:])%5 and hidden==(int(oid[-4:])==25) for oid,status,hidden in orders)};connection.close()
 assert counts=={'goods_sku':115,'orders_order_info':27,'support_ai_supportturn':0} and checks[arm]['order_states_match']
integrity['fixture_integrity']=checks
calls=[json.loads(v) for v in (OUT/'api-calls.jsonl').read_text(encoding='utf8').splitlines()];ids=[c['response_id'] for c in calls if c.get('response_id')]
integrity['api_response_ids_unique']=len(ids)==len(set(ids));integrity['token_accounting_consistent']=all(c['usage']['prompt_tokens']==c['usage'].get('prompt_cache_hit_tokens',0)+c['usage'].get('prompt_cache_miss_tokens',0) for c in calls if c.get('usage'))
snapshot=[(c['id'],c['text']) for c in load('public-knowledge.json')];integrity['public_export_matches_database_snapshot']=hashlib.sha256(json.dumps(snapshot,ensure_ascii=False).encode('utf8')).hexdigest()==load('run-state.json')['postgresql']['public_corpus_sha256']
assert integrity['api_response_ids_unique'] and integrity['token_accounting_consistent'] and integrity['public_export_matches_database_snapshot'];save('integrity.json',integrity)
with zipfile.ZipFile(OUT/'procedures.zip','w',zipfile.ZIP_DEFLATED) as z:
 for f in HERE.rglob('*.py'):
  if '__pycache__' not in str(f):z.write(f,str(f.relative_to(HERE)))
save('file-sha256.json',{f.name:hashlib.sha256(f.read_bytes()).hexdigest() for f in OUT.iterdir() if f.is_file() and f.name not in ['file-sha256.json','review-working.txt']})
print(json.dumps({'fixture_checks':checks,'report':str(p),'delta_percent':{'mean_latency':pct(new['latency_seconds']['mean'],old['latency_seconds']['mean']),'p95_latency':pct(new['latency_seconds']['p95'],old['latency_seconds']['p95']),'known_usage_cost':pct(new['usage']['cost_usd_peak'],old['usage']['cost_usd_peak'])}},ensure_ascii=True))
