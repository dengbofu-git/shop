import os,sys,json,shutil
from pathlib import Path
from datetime import datetime,timedelta
import pytz
HERE=Path(__file__).parent;ROOT=HERE.parents[1];OUT=ROOT/'docs/agent测试文本/2026-10-26-real-100-run-01'
sys.path[:0]=[str(HERE),str(ROOT)];os.environ['DJANGO_SETTINGS_MODULE']='eval_settings'
import django;django.setup()
from django.core.management import call_command
from django.db import connections
assert connections['default'].settings_dict['ENGINE']=='django.db.backends.sqlite3'
call_command('migrate',database='default',interactive=False,verbosity=0)
from goods.models import Catalog,Brand,SPU,SKU,SPUSaleAttr,SaleAttrValue
from users.models import UserProfile
from orders.models import OrderInfo,TrialOrder,PreSaleOrder
from ai_storage.models import BuyerMemory
for p in json.loads((OUT/'public-products.json').read_text(encoding='utf8')):
 Catalog.objects.get_or_create(pk=p['catalog_id'],defaults={'name':p['category']})
 if p['brand_id']:Brand.objects.get_or_create(pk=p['brand_id'],defaults={'name':p['brand'],'first_letter':'E'})
 SPU.objects.get_or_create(pk=p['spu_id'],defaults={'name':p['product_name'],'catalog_id':p['catalog_id'],'brand_id':p['brand_id']})
 s=SKU.objects.create(pk=p['id'],name=p['name'],caption=p['caption'],price=p['price'],market_price=p['market_price'],cost_price='0.01',stock=p['stock'],sales=p['sales'],spu_id=p['spu_id'])
 for a in p['attrs']:
  attr,_=SPUSaleAttr.objects.get_or_create(spu_id=p['spu_id'],name=a['name']);v,_=SaleAttrValue.objects.get_or_create(spu_sale_attr=attr,name=a['value']);s.sale_attr_value.add(v)
users=[]
for i in range(1,4):users.append(UserProfile.objects.create(pk=900000+i,username='evalbuyer'+str(i),password='not-a-login-password',is_active=True,user_type='customer'))
orders=[]
for i in range(1,28):
 owner=users[0] if i<=25 else users[1]
 kind='trial' if i==23 else 'presale' if i==24 else 'standard'
 o=OrderInfo.objects.create(user_profile=owner,order_id='EVAL20261026%04d'%i,order_type=kind,total_amount='99.00',total_count=1,freight='0.00',status=i%5,buyer_hidden=i==25,receiver='测试人',address='隔离测试地址',receiver_mobile='13900000000',tag='eval')
 if kind=='trial':TrialOrder.objects.create(order_info=o,status=4)
 if kind=='presale':PreSaleOrder.objects.create(order_info=o,status=3,deposit_amount='20',balance_amount='79')
 at=pytz.timezone('Asia/Shanghai').localize(datetime(2026,10,26,10,0)-timedelta(days=i-1))
 OrderInfo.objects.filter(pk=o.pk).update(created_time=at)
 orders.append({'id':o.pk,'owner_fixture':1 if i<=25 else 2,'hidden':i==25,'type':kind,'created_at':at.isoformat(),'status':i%5})
with connections['memory_eval'].schema_editor() as editor:editor.create_model(BuyerMemory)
BuyerMemory.objects.create(owner_id=900001,preferences={'categories':['红茶'],'brands':[],'keywords':[]})
connections.close_all()
for arm in ['baseline','current']:shutil.copy2(HERE/'fixtures.sqlite3',HERE/(arm+'.sqlite3'))
(OUT/'private-fixtures.json').write_text(json.dumps({'synthetic_only':True,'orders':orders,'memory':{'owner_fixture':1,'categories':['红茶']}},ensure_ascii=False,indent=2),encoding='utf8')
print('Isolated catalogue/order/memory fixtures ready; no production migrations or writes.')
