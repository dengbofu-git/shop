import os,sys,json,hashlib,subprocess,zipfile,io,shutil
from pathlib import Path
from dataclasses import asdict
ROOT=Path(r'E:\django\dadashop'); HERE=Path(__file__).parent
OUT=ROOT/'docs/agent测试文本/2026-10-26-real-100-run-01'
OUT.mkdir(parents=True,exist_ok=False)
sys.path.insert(0,str(ROOT));os.environ['DJANGO_SETTINGS_MODULE']='tea_saas.settings'
import django;django.setup()
from support_ai.configuration import effective_configuration
from support_ai.recommendations import available_products
from ai_storage.models import KnowledgeChunk
from goods.models import SPUSpec
def save(n,v): (OUT/n).write_text(json.dumps(v,ensure_ascii=False,indent=2,default=str)+'\n',encoding='utf-8')
save('config.json',asdict(effective_configuration()))
products=[]
for s in available_products().order_by('pk'):
 products.append(dict(id=s.pk,name=s.name,caption=s.caption,price=str(s.price),market_price=str(s.market_price),stock=s.available_stock,sales=s.sales,spu_id=s.spu_id,product_name=s.spu.name,catalog_id=s.spu.catalog_id,category=s.spu.catalog.name,brand_id=s.spu.brand_id,brand=s.spu.brand.name if s.spu.brand_id else '',attrs=[{'name':a.spu_sale_attr.name,'value':a.name} for a in s.sale_attr_value.all()]))
save('public-products.json',products)
chunks=[dict(id=c.pk,document_id=str(c.document_id),version=c.document.version,title=c.document.title,url=c.document.source_reference,text=c.text) for c in KnowledgeChunk.objects.filter(document__status='published',document__visibility='public',embedding__isnull=False).select_related('document').order_by('pk')]
save('public-knowledge.json',chunks)
baseline='bf8ec1bd3666781267d03700c3852d209e822800'
data=subprocess.check_output(['git','archive','--format=zip',baseline,'support_ai'],cwd=ROOT)
with zipfile.ZipFile(io.BytesIO(data)) as z:z.extractall(HERE/'baseline')
shutil.copytree(ROOT/'support_ai',HERE/'current/support_ai',ignore=shutil.ignore_patterns('__pycache__'))
hashes={}
for arm in ['baseline','current']:
 hashes[arm]={str(p.relative_to(HERE/arm)):hashlib.sha256(p.read_bytes()).hexdigest() for p in (HERE/arm/'support_ai').rglob('*.py')}
save('source-manifest.json',{'baseline_commit':baseline,'baseline_version':'0.12.3','current_version':'0.20.1','source_hashes':hashes,'dependency_scope':'support_ai source isolated per arm; current shared application models and provider adapters; same public SKU snapshot and live public-only PostgreSQL RAG; synthetic private fixtures only','public_products':len(products),'public_chunks':len(chunks)})
print(json.dumps({'output':str(OUT),'products':len(products),'chunks':len(chunks),'examples':[{k:p[k] for k in ['id','product_name','name','category','price','brand']} for p in products[::18]],'titles':list(dict.fromkeys(c['title'] for c in chunks))},ensure_ascii=True))
