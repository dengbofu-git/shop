Recorded execution: prepare.py; fixtures.py; build_cases.py; run.py; analyze.py; finalize.py.
The run directory is fixed and prepare/run refuse overwriting existing evidence. Reproduction requires a fresh output path/copy, original local environment credentials, public services and the project dependencies.
No .env files, API keys or real customer records are included. Long-term memory and business records are isolated SQLite fixtures; live PostgreSQL is shared-snapshot read-only public retrieval only.
On this Python 3.9 host the post-processing scripts were executed by reading UTF-8 and compile/exec; actual runtime workers were invoked directly.
