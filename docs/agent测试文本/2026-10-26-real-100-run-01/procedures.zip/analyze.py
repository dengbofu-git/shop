# -*- coding: utf-8 -*-
import json,statistics,math,hashlib,zipfile,shutil,re
from pathlib import Path
from collections import Counter,defaultdict
from datetime import datetime
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1];OUT=ROOT/'docs/agent测试文本/2026-10-26-real-100-run-01'
def load(n):return json.loads((OUT/n).read_text(encoding='utf8'))
def lines(n):return [json.loads(s) for s in (OUT/n).read_text(encoding='utf8').splitlines()]
def save(n,v):(OUT/n).write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
cases=load('cases-100.json');byid={c['id']:c for c in cases};data={a:lines(a+'-results.jsonl') for a in ['baseline','current']}
assert all(len(rs)==100 and len({r['id'] for r in rs})==100 for rs in data.values())
review=load('manual-review.json') if (OUT/'manual-review.json').exists() else {}
excluded_sessions={c['session'] for c in cases if c['comparison']!='common' or re.search(r'预算|美元|人民币|[0-9]+(?:\.[0-9]+)?元',c['message'])}
common_ids={c['id'] for c in cases if c['session'] not in excluded_sessions}
save('comparability.json',{'method':'Exclude changed-business-rule cases and the entire sessions containing order/currency/budget scenarios, so changed context does not leak into common subset','common_ids':sorted(common_ids),'excluded_ids':[c['id'] for c in cases if c['id'] not in common_ids]})
def quantile(xs,p):
 xs=sorted(xs);index=(len(xs)-1)*p;low=int(index);high=min(low+1,len(xs)-1);return xs[low]+(xs[high]-xs[low])*(index-low)
def stats(xs):return {'mean':statistics.mean(xs),'p50':quantile(xs,.5),'p95':quantile(xs,.95),'max':max(xs)} if xs else None
def usage(api):
 sums=Counter({k:0 for k in ['calls','input_tokens','output_tokens','reasoning_tokens','cache_hit_tokens','cache_miss_tokens','usage_missing_calls']})
 for call in api:
  u=call.get('usage',{});sums['input_tokens']+=u.get('prompt_tokens',0);sums['output_tokens']+=u.get('completion_tokens',0);sums['reasoning_tokens']+=(u.get('completion_tokens_details') or {}).get('reasoning_tokens',0)
  hit=u.get('prompt_cache_hit_tokens',(u.get('prompt_tokens_details') or {}).get('cached_tokens',0));miss=u.get('prompt_cache_miss_tokens',u.get('prompt_tokens',0)-hit)
  sums['cache_hit_tokens']+=hit;sums['cache_miss_tokens']+=miss;sums['calls']+=1;sums['usage_missing_calls']+=not bool(u)
 sums['cost_usd_offpeak']=sums['cache_hit_tokens']*.003/1e6+sums['cache_miss_tokens']*.15/1e6+sums['output_tokens']*.6/1e6
 sums['cost_usd_peak']=sums['cost_usd_offpeak']*2
 return dict(sums)
summary={}
for arm,rs in data.items():
 api=[v for r in rs for v in r['api']];local=[v for r in rs for v in r['local']]
 reviewed={r['id']:review.get(arm,{}).get(r['id']) for r in rs}
 common=[r for r in rs if r['id'] in common_ids];normal=[r for r in rs if r['mode']=='normal']
 summary[arm]={'total':len(rs),'automatic_status':dict(Counter(r['status'] for r in rs)),'review_overrides':sum(v is not None for v in reviewed.values()),'reviewed_pass':sum((reviewed[r['id']]['pass'] if reviewed[r['id']] is not None else r['status']=='passed') for r in rs),'common_cases':len(common),'common_automatic_pass':sum(r['status']=='passed' for r in common),'common_reviewed_pass':sum((reviewed[r['id']]['pass'] if reviewed[r['id']] is not None else r['status']=='passed') for r in common),'latency_seconds':stats([r['duration_seconds'] for r in rs]),'normal_latency_seconds':stats([r['duration_seconds'] for r in normal]),'model_path_latency_seconds':stats([r['duration_seconds'] for r in rs if r['api']]),'rule_path_latency_seconds':stats([r['duration_seconds'] for r in rs if not r['api']]),'client_cpu_seconds':sum(r['client_cpu_seconds'] for r in rs),'usage':usage(api),'local_services':{svc:{'calls':sum(v['service']==svc for v in local),'latency_seconds':stats([v['seconds'] for v in local if v['service']==svc]),'http_statuses':dict(Counter(str(v.get('http_status',v.get('error_type'))) for v in local if v['service']==svc))} for svc in ['embedding','rerank']},'groups':{g:{'count':sum(r['group']==g for r in rs),'automatic_pass':sum(r['group']==g and r['status']=='passed' for r in rs),'reviewed_pass':sum(r['group']==g and (reviewed[r['id']]['pass'] if reviewed[r['id']] is not None else r['status']=='passed') for r in rs)} for g in dict.fromkeys(c['group'] for c in cases)}}
for arm,rs in data.items():
 summary[arm]['common_latency_seconds']=stats([r['duration_seconds'] for r in rs if r['id'] in common_ids])
 summary[arm]['common_usage']=usage([v for r in rs if r['id'] in common_ids for v in r['api']])
 summary[arm]['clarification_turns']=sum(r.get('response',{}).get('clarification_required',False) for r in rs)
 summary[arm]['compliance_blocked_turns']=sum(r.get('response',{}).get('compliance_blocked',False) for r in rs)
 kr=[review.get(arm,{}).get(c['id']) for c in cases if c['group']=='真实知识检索']
 summary[arm]['knowledge_manual_review']={'reviewed':sum(v is not None for v in kr),'strict_pass':sum(v is not None and v['pass'] for v in kr),'core_correct':sum(v is not None and v.get('core_correct',v['pass']) for v in kr),'explicit_unsupported_claims':sum(v is not None and v.get('grounded') is False for v in kr)}
 for group,g in summary[arm]['groups'].items():
  subset=[r for r in rs if r['group']==group]
  g['latency_seconds']=stats([r['duration_seconds'] for r in subset]);g['usage']=usage([v for r in subset for v in r['api']])
prior=load('../../../../reports/agent-evaluation/2026-10-26-rerank-query-ab/run-2/cases.json') if False else json.loads((ROOT/'reports/agent-evaluation/2026-10-26-rerank-query-ab/run-2/cases.json').read_text(encoding='utf8'))
rag={}
for arm,rs in data.items():
 rows=[]
 for c,old in zip(cases[40:55],prior):
  r=next(v for v in rs if v['id']==c['id']);ids=list(dict.fromkeys(int(v) for a in r['retrieval'] for v in a.get('selected_ids',[])));rel=set(old['relevant_ids']);groups=old['support_groups']
  covered=sum(bool(set(g)&set(ids)) for g in groups);ratings=[old['grades'].get(str(v),0) for v in ids[:5]];ideal=sorted(old['grades'].values(),reverse=True)[:5]
  dcg=lambda vals:sum((2**g-1)/math.log2(i+2) for i,g in enumerate(vals))
  rows.append({'id':c['id'],'selected_ids':ids,'retrieval_entered':bool(r['retrieval']),'relevant_precision':len(set(ids)&rel)/len(ids) if ids else 0,'support_coverage':covered/len(groups) if groups else None,'ndcg_at_5':dcg(ratings)/dcg(ideal) if ideal and dcg(ideal) else None,'answer_goal':old['answer_goal']})
 rag[arm]={'scope':'15 pre-labelled knowledge questions; selected evidence after real retrieval; missing retrieval counts as zero; pooled unique selected IDs in request order; labels from earlier frozen public corpus; not raw reranker-only scores','cases':rows,'retrieval_entered':sum(r['retrieval_entered'] for r in rows),'mean_precision':statistics.mean(r['relevant_precision'] for r in rows),'mean_support_coverage':statistics.mean(r['support_coverage'] for r in rows if r['support_coverage'] is not None),'mean_ndcg_at_5':statistics.mean(r['ndcg_at_5'] for r in rows if r['ndcg_at_5'] is not None)}
save('retrieval-quality.json',rag);save('summary.json',summary)
records=['# 100条真实模型配对测试记录','', '每条均含本次实际输出；旧版0.12.3、当前版0.20.1。原始完整字段见对应 `*-results.jsonl`。人工复核与原始自动判分分别保留。','']
for c in cases:
 records+=['## '+c['id']+' · '+c['group'],'',c['message'],'', '**预期检查**：`'+json.dumps(c['checks'],ensure_ascii=False)+'`','']
 for arm,label in [('current','当前版'),('baseline','旧版')]:
  r=next(v for v in data[arm] if v['id']==c['id']);u=usage(r['api']);rv=review.get(arm,{}).get(c['id']);status=('通过' if rv['pass'] else '未通过') if rv else ('通过' if r['status']=='passed' else '未通过')
  records+=['### '+label+'：'+status,'',r.get('response',{}).get('answer','运行异常：'+r.get('error_type','unknown')),'',f"耗时 {r['duration_seconds']:.3f}s；模型调用 {u['calls']}；输入/输出 Token {u['input_tokens']}/{u['output_tokens']}；API费用估算 ${u['cost_usd_offpeak']:.6f}–${u['cost_usd_peak']:.6f}。",'', '自动检查：`'+json.dumps(r['checks'],ensure_ascii=False)+'`','']
  if rv:records+=['复核：'+rv['reason'],'']
(OUT/'逐条实际记录.md').write_text('\n'.join(records),encoding='utf8')
comparison=['| 指标 | 旧版0.12.3 | 当前版0.20.1 |','|---|---:|---:|']
for label,fn in [('自动约束通过数',lambda s:str(s['automatic_status'].get('passed',0))+'/100'),('复核后场景通过数',lambda s:str(s['reviewed_pass'])+'/100'),('共同规则子集通过数',lambda s:str(s['common_reviewed_pass'])+'/'+str(s['common_cases'])),('平均耗时',lambda s:'%.3fs'%s['latency_seconds']['mean']),('P50耗时',lambda s:'%.3fs'%s['latency_seconds']['p50']),('P95耗时',lambda s:'%.3fs'%s['latency_seconds']['p95']),('模型调用次数',lambda s:str(s['usage']['calls'])),('缺少usage的调用次数',lambda s:str(s['usage']['usage_missing_calls'])),('输入Token',lambda s:str(s['usage']['input_tokens'])),('输出Token（含思考）',lambda s:str(s['usage']['output_tokens'])),('缓存命中Token',lambda s:str(s['usage']['cache_hit_tokens'])),('API费用估算USD',lambda s:'$%.6f–$%.6f'%(s['usage']['cost_usd_offpeak'],s['usage']['cost_usd_peak']))]:comparison.append('| '+label+' | '+fn(summary['baseline'])+' | '+fn(summary['current'])+' |')
text=['# 100条真实场景Agent评测：质量、成本与性能','', '本次实际执行100条当前版和100条旧版，采用同一组问题、同一公开商品快照、同一PostgreSQL只读共享快照及相同模型参数，按条交替AB/BA顺序调用。统计包含失败与澄清，未用重试替换失败结果。','',*comparison,'','## 口径与边界','', '- 真实链路：配置模型deepseek-flash、thinking enabled、temperature=0、单次超时45s、SDK重试0、请求max_tokens=4096（部分实际usage含思考后超过此值，以服务实际回传为准）；查询改写保留源码自己的更短超时与输出限制。实际模型调用数可能为0：固定欢迎语或程序规则路径本就无需模型。','- 真实检索：Ollama嵌入、PostgreSQL pgvector公开语料召回、RRF、实际本地重排与证据选择；公开语料冻结为50片段。每个知识问题未必进入检索，规划拒绝或澄清同样保留并计入失败。','- 商品：真实应用数据库的115个当时可售SKU公开快照，包含演示/模拟商品；复制到SQLite后使用实际程序查询。库存以快照时可售量展平，不测生产MySQL吞吐、仓库账本并发或订单写入。复制公开销售属性，未复制ProductAttributeValue扩展详情属性；缺少属性不能据此判断生产没有配置。','- 订单/偏好：仅合成账号、27笔隔离订单与明确的红茶偏好；使用实际订单查询及saved_preferences代码，存储为隔离SQLite。本次不测长期记忆PostgreSQL读写性能，不接触真实买家订单、偏好或会话。','- 版本：旧版support_ai源码来自bf8ec1bd3666781267d03700c3852d209e822800，14个关键文件与2026-10-19旧报告源码一致；当前版源码在运行前复制冻结。两版共享当前基础应用模型与基础适配器，因此是Agent模块历史对比，不是完整历史部署复刻。','- 业务变化：旧版USD基础币种、旧订单实现与当前CNY及全部/时间范围订单规则不同，原始相关条目标记changed_business_rules；统计进一步排除包含预算、币种或订单变更的整个会话（见comparability.json），防止上下文差异混入共同规则子集。总表按当前要求验收。不能把全部差异归因于单独的“仅原问题重排”。','- 评测层次：实际Agent图与工具集成测试，不是HTTP认证、幂等提交、浏览器或完整生产端到端测试。隐私仅检查合成敏感值与公开结果字段，不代表完整安全认证。','- 质量：自动通过是预先冻结约束的通过率，人工复核覆盖另行列明；事实核对以冻结知识片段为依据，未独立审核每份来源的外部真实性；无独立专家盲审，不代表线上用户准确率。详情宽泛/安全拒绝等只有有限断言，见每条预期。','', '## 分场景结果','', '| 场景 | 数量 | 旧版复核通过 | 当前复核通过 |','|---|---:|---:|---:|']
for group,s in summary['current']['groups'].items():text.append('| '+group+' | '+str(s['count'])+' | '+str(summary['baseline']['groups'][group]['reviewed_pass'])+' | '+str(s['reviewed_pass'])+' |')
text+=['','## 检索相关性','', '| 15条预标注知识子集 | 旧版 | 当前版 |','|---|---:|---:|', '| 实际进入检索条数 | '+str(rag['baseline']['retrieval_entered'])+' | '+str(rag['current']['retrieval_entered'])+' |']
for key,label in [('mean_precision','最终证据相关精度'),('mean_support_coverage','核心证据组覆盖率'),('mean_ndcg_at_5','最终证据nDCG@5')]:text.append('| '+label+' | %.4f | %.4f |'%(rag['baseline'][key],rag['current'][key]))
text+=['','标签沿用同日已冻结公开语料人工标注；这里测实际整条Agent链路的最终证据，未进入检索按零计分。跨多个知识子任务时按审计顺序合并去重，相关性指标不是单独重排器的性能。细节及每题选择片段见retrieval-quality.json。','', '## 成本与性能解释','', 'API费用只对本次HTTP成功返回usage的调用逐次汇总；请求超时等缺少usage的调用数量另计，可能产生无法核实的额外账单费用，因此范围不是全部实扣的完整上下界。费用部分，缓存命中/未命中分别计价；输出Token已含reasoning_tokens，不重复加算。依DeepSeek官方2026-10-26价格：每百万Token非高峰缓存命中$0.003、未命中$0.15、输出$0.6，高峰为其两倍。给出全非高峰至全高峰的估算范围，非账单实扣金额。来源：[DeepSeek官方价格](https://api-docs.deepseek.com/quick_start/pricing/)。','', '本地嵌入和重排没有新增按Token付费，仍有硬件、用电和CPU占用；未提供硬件单价，不能将其总成本写为0。summary.json记录实际服务请求数、HTTP耗时、失败状态和客户端CPU秒；客户端CPU不包括Docker服务CPU。计时包括评测客户端按条构建模型适配器的开销，规则路径亦有这部分开销；它不同于线上固定欢迎语直接返回的HTTP延迟。串行测量不等于生产QPS或并发压测，API缓存共享、首次加载和运行时外部负载可能影响两版延迟和成本。','', '## 失败与复核','']
for arm,label in [('current','当前版'),('baseline','旧版')]:
 text+=['### '+label,'']
 for r in data[arm]:
  rv=review.get(arm,{}).get(r['id']);passed=rv['pass'] if rv else r['status']=='passed'
  if not passed:text.append('- '+r['id']+'：'+(rv['reason'] if rv else '未通过 '+', '.join(k for k,v in r['checks'].items() if not v)+('；'+r.get('error_type','') if r.get('error_type') else '')))
text+=['','## 可复核文件','', '- cases-100.json：冻结输入与预期检查。','- current-results.jsonl / baseline-results.jsonl：完整实际响应、任务计划、工具结果、检索审计及每条用量。','- 逐条实际记录.md：100组双版本完整答复与成本耗时。','- api-calls.jsonl / local-calls.jsonl：模型API usage与本地服务实际请求耗时，不含API密钥与模型思考原文。','- public-products.json / public-knowledge.json / private-fixtures.json：公开输入快照及明确标记的合成私有测试数据。','- source-manifest.json / run-state.json / completion.json / integrity.json：源码指纹、共享只读快照、运行结束和完整性。','- procedures.zip：本次脚本与冻结Agent源码；依赖服务与原.env仍需本机配置，凭据不打包。','', '未修改业务代码，未提交、推送、部署或写入生产数据。']
(OUT/'测试报告.md').write_text('\n'.join(text)+'\n',encoding='utf8')
manifest=load('source-manifest.json');unchanged={a:all(hashlib.sha256((HERE/a/p).read_bytes()).hexdigest()==h for p,h in manifest['source_hashes'][a].items()) for a in ['baseline','current']}
integrity={'records':{a:len(rs) for a,rs in data.items()},'unique_ids':{a:len({r['id'] for r in rs}) for a,rs in data.items()},'frozen_agent_source_unchanged':unchanged,'api_log_calls':len(lines('api-calls.jsonl')),'per_case_api_calls':sum(len(r['api']) for rs in data.values() for r in rs),'no_production_business_writes':'runner routes default and memory to isolated SQLite; PostgreSQL repeatable-read read-only shared snapshot; enforced owner None for live search'}
assert integrity['api_log_calls']==integrity['per_case_api_calls'] and all(unchanged.values())
save('integrity.json',integrity)
with zipfile.ZipFile(OUT/'procedures.zip','w',zipfile.ZIP_DEFLATED) as z:
 for p in HERE.rglob('*.py'):
  if '__pycache__' not in str(p):z.write(p,str(p.relative_to(HERE)))
print(json.dumps({'summary':summary,'retrieval':{a:{k:v for k,v in s.items() if k!='cases'} for a,s in rag.items()},'integrity':integrity},ensure_ascii=True))
