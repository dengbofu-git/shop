import json,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];OUT=ROOT/'docs/agent测试文本/2026-10-26-real-100-run-01'
start=int(sys.argv[1]);end=int(sys.argv[2]);parts=[]
for arm in ['current','baseline']:
 parts.append('\n# '+arm)
 for line in (OUT/(arm+'-results.jsonl')).read_text(encoding='utf8').splitlines():
  r=json.loads(line);number=int(r['id'][1:])
  if start<=number<=end:
   parts.append('\n## '+r['id']+' '+r['message']+' ['+r['status']+']\n'+r.get('response',{}).get('answer','ERROR '+r.get('error_type','')))
(OUT/'review-working.txt').write_text('\n'.join(parts),encoding='utf8')
