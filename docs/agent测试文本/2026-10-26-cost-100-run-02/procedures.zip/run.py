import os,sys,json,subprocess,time,ctypes
from pathlib import Path
from datetime import datetime,timezone
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1];OUT=ROOT/'docs/agent测试文本/2026-10-26-cost-100-run-02'
def save(n,v):(OUT/n).write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
def start(arm,snapshot=None):
 env=os.environ.copy();env['PYTHONIOENCODING']='utf-8';env['PYTHONUNBUFFERED']='1'
 if snapshot:env['EVAL_PG_SNAPSHOT']=snapshot
 err=(OUT/(arm+'-stderr.log')).open('w',encoding='utf8')
 p=subprocess.Popen([sys.executable,str(HERE/'worker.py'),arm],cwd=ROOT,env=env,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=err,text=True,encoding='utf8',bufsize=1)
 line=p.stdout.readline()
 if not line:raise RuntimeError('Worker startup failed: '+arm)
 ready=json.loads(line);print(json.dumps(ready),flush=True);return p,ready
if any((OUT/(a+'-results.jsonl')).exists() for a in ['after','before']):raise RuntimeError('Never overwrite a run')
ctypes.windll.kernel32.SetThreadExecutionState(0x80000001);workers={};started=datetime.now(timezone.utc).isoformat()
try:
 workers['after'],current=start('after');workers['before'],baseline=start('before',current['snapshot'])
 assert current['public_corpus_sha256']==baseline['public_corpus_sha256']
 save('run-state.json',{'started_at':started,'status':'running','postgresql':{'shared_read_only_snapshot':True,'public_corpus_sha256':current['public_corpus_sha256'],'chunks':current['public_chunks']},'protocol':'same cases/config/fixtures; alternating AB/BA case order; sequential requests, real public pgvector recall and rerank; frozen support_ai source; frozen shared infrastructure/models; both arms use identical current business rules; before arm reverses only cost-control files; local account/order/memory fixtures; entry graph test, not HTTP/browser E2E'})
 cases=json.loads((OUT/'cases-100.json').read_text(encoding='utf8'))
 for i,c in enumerate(cases):
  for arm in (['after','before'] if i%2==0 else ['before','after']):
   p=workers[arm];p.stdin.write(json.dumps(c,ensure_ascii=False)+'\n');p.stdin.flush();line=p.stdout.readline()
   if not line:raise RuntimeError('Worker stopped: '+arm)
   print(line.strip(),flush=True)
 save('completion.json',{'started_at':started,'completed_at':datetime.now(timezone.utc).isoformat(),'status':'completed','records_per_arm':100})
finally:
 for p in workers.values():
  if p.poll() is None:p.stdin.write('{"stop":true}\n');p.stdin.flush()
 for p in workers.values():p.wait(timeout=30)
 ctypes.windll.kernel32.SetThreadExecutionState(0x80000000)
