# -*- coding: utf-8 -*-
import ast,hashlib,json,shutil
from pathlib import Path

ROOT=Path(r'E:\django\dadashop');HERE=Path(__file__).parent
OLD=ROOT/'docs/agent测试文本/2026-10-26-real-100-run-01'
OUT=ROOT/'docs/agent测试文本/2026-10-26-cost-100-run-02'
PRE=ROOT/'.scratch/agent-cost-control-20261026/before/support_ai'
OUT.mkdir(parents=True,exist_ok=False)
def save(n,v):(OUT/n).write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
packages=[p for p in ROOT.iterdir() if p.is_dir() and (p/'__init__.py').exists()]
inputs=[]
for package in packages:
 if package.name=='support_ai':continue
 inputs.extend(p for p in package.rglob('*.py') if '__pycache__' not in p.parts)
inputs.append(ROOT/'tea_saas/currency.json')
shared_hashes={str(p.relative_to(ROOT)):digest(p) for p in inputs}
for p in inputs:
 target=HERE/'shared'/p.relative_to(ROOT);target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,target)
assert shared_hashes=={str(p.relative_to(ROOT)):digest(p) for p in inputs},'Shared code changed during freeze'
for arm in ['before','after']:
 shutil.copytree(ROOT/'support_ai',HERE/arm/'support_ai',ignore=shutil.ignore_patterns('__pycache__'))
assert {str(p.relative_to(HERE/'before')):digest(p) for p in (HERE/'before/support_ai').rglob('*.py')}=={str(p.relative_to(HERE/'after')):digest(p) for p in (HERE/'after/support_ai').rglob('*.py')}
CONTROL=HERE/'before/support_ai'
for name in ['model_client.py','grounding.py','tea_explanation.py','execution.py']:
 shutil.copy2(PRE/name,CONTROL/name)
p=CONTROL/'business_grounding.py';text=p.read_text(encoding='utf8')
first=text.index('\ndef _fixed_insufficient_text(');last=text.index('\ndef render_product_details(')
p.write_text(text[:first]+text[last:],encoding='utf8')
p=CONTROL/'workflow.py';text=p.read_text(encoding='utf8')
text=text.replace(', needs_model_review','').replace('from .cost_control import BudgetedGraph, ModelBudgetExceeded\n','')
start=text.index('        try:\n            verdict = compliance.invoke(',text.index('    def check(state):'))
end=text.index('        # A safety reviewer',start)
text=text[:start]+"        verdict = compliance.invoke({**text_inputs(state), 'answer': state['answer']})\n"+text[end:]
start=text.index('    def review_route(state):');end=text.index('    def finalize(state):',start);text=text[:start]+text[end:]
prior=(PRE/'workflow.py').read_text(encoding='utf8');start=prior.index("    graph.add_conditional_edges('compose',")
end=prior.index("    graph.add_edge('compliance'",start)
replacement=prior[start:end];start=text.index("    graph.add_conditional_edges('compose',")
end=text.index("    graph.add_edge('compliance'",start);text=text[:start]+replacement+text[end:]
text=text.replace('    compiled = graph.compile()\n    return BudgetedGraph(compiled) if model is not None else compiled','    return graph.compile()')
assert 'BudgetedGraph' not in text and 'needs_model_review' not in text
ast.parse(text);p.write_text(text,encoding='utf8')
oldrunner=ROOT/'.scratch/real100-20261026'
for name in ['cases-100.json','config.json','public-products.json','public-knowledge.json','private-fixtures.json']:
 shutil.copy2(OLD/name,OUT/name)
for arm in ['before','after']:shutil.copy2(oldrunner/'fixtures.sqlite3',HERE/(arm+'.sqlite3'))
shutil.copy2(oldrunner/'memory.sqlite3',HERE/'memory.sqlite3')
for name in ['eval_settings.py','eval_router.py']:shutil.copy2(oldrunner/name,HERE/name)
worker=(oldrunner/'worker.py').read_text(encoding='utf8')
worker=worker.replace('2026-10-26-real-100-run-01','2026-10-26-cost-100-run-02')
worker=worker.replace("sys.path[:0]=[str(HERE/ARM),str(HERE),str(ROOT)]", "from dotenv import load_dotenv\nload_dotenv(ROOT/'.env',override=False);load_dotenv(ROOT/'.env.postgres',override=False)\nsys.path[:0]=[str(HERE/ARM),str(HERE),str(HERE/'shared'),str(ROOT)]")
worker=worker.replace("if ARM=='current'", "if ARM in ('before','after')")
worker=worker.replace("if ARM=='baseline'", "if ARM=='unused-legacy'")
worker=worker.replace("start=time.perf_counter();record={'arm':ARM", "start=time.perf_counter();body=json.loads(request.content) if request.content else {};record={'arm':ARM")
worker=worker.replace("try:\n  response=original_http", "try:\n  if 'deepseek' in request.url.host:\n   record['request_options']={k:body.get(k) for k in ['model','thinking','max_tokens','max_completion_tokens','response_format']}\n   record['schema']=body['tools'][0]['function']['name'] if body.get('tools') else None\n   if not record['schema'] and body.get('messages') and 'JSON Schema' in str(body['messages'][0].get('content','')):\n    record['schema']=json.loads(body['messages'][0]['content'].split('\\n',1)[1]).get('title')\n   record['sensitive_input_hits']=[s for s in ['13900001234','eval.customer@example.invalid'] if s in request.content.decode('utf8')]\n  response=original_http")
ast.parse(worker);(HERE/'worker.py').write_text(worker,encoding='utf8')
run=(oldrunner/'run.py').read_text(encoding='utf8').replace('2026-10-26-real-100-run-01','2026-10-26-cost-100-run-02')
run=run.replace("['current','baseline']","['after','before']").replace("['baseline','current']","['before','after']")
run=run.replace("workers['current'],current=start('current');workers['baseline'],baseline=start('baseline',current['snapshot'])", "workers['after'],current=start('after');workers['before'],baseline=start('before',current['snapshot'])")
run=run.replace('current shared infrastructure/models','frozen shared infrastructure/models; both arms use identical current business rules; before arm reverses only cost-control files')
(HERE/'run.py').write_text(run,encoding='utf8');ast.parse(run)
hashes={a:{str(p.relative_to(HERE/a)):digest(p) for p in (HERE/a/'support_ai').rglob('*.py')} for a in ['before','after']}
changed=[p for p,h in hashes['after'].items() if hashes['before'].get(p)!=h]
assert sorted(Path(p).name for p in changed)==sorted(['model_client.py','grounding.py','tea_explanation.py','execution.py','workflow.py','business_grounding.py']),changed
save('source-manifest.json',{'workspace_version':json.loads((ROOT/'versions/modules.json').read_text(encoding='utf8'))['modules']['support_ai']['version'],'scope':'Counterfactual before/after cost changes on identical frozen current business code; not a historical deployment replica','source_sha256':hashes,'shared_source_sha256':shared_hashes,'cost_change_files':changed,'frozen_inputs_sha256':{n:digest(OUT/n) for n in ['cases-100.json','config.json','public-products.json','public-knowledge.json','private-fixtures.json']},'fixture_sha256':{n:digest(HERE/n) for n in ['before.sqlite3','after.sqlite3','memory.sqlite3']}})
print(json.dumps({'prepared':str(OUT),'cases':100,'source_difference_files':len(changed),'shared_python_files':len(shared_hashes)},ensure_ascii=True))
