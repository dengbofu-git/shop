import os,sys,json,time,hashlib,ctypes,traceback
from pathlib import Path
from dataclasses import replace
from types import SimpleNamespace
from datetime import datetime,timezone as utc
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1];OUT=ROOT/'docs/agent测试文本/2026-10-26-cost-100-run-02'
ARM=sys.argv[1];os.environ['EVAL_DB']=ARM+'.sqlite3';os.environ['DJANGO_SETTINGS_MODULE']='eval_settings'
from dotenv import load_dotenv
load_dotenv(ROOT/'.env',override=False);load_dotenv(ROOT/'.env.postgres',override=False)
sys.path[:0]=[str(HERE/ARM),str(HERE),str(HERE/'shared'),str(ROOT)]
import django;django.setup()
from django.db import connections,transaction
from django.utils import timezone
from support_ai.configuration import AgentConfig
from support_ai.model_client import configured_model
from support_ai.context import context_from_turns,saved_preferences
from support_ai.tool_services import create_tool_handlers
from support_ai.workflow import build_graph
from support_ai.retrieval import KnowledgeRetriever
from support_ai import workflow
from support_ai.pii import redact
from users.models import UserProfile
from goods.models import SKU
from orders.models import OrderInfo
import httpx,requests
CONFIG=replace(AgentConfig(**json.loads((OUT/'config.json').read_text(encoding='utf8'))),telemetry_enabled=False,export_enabled=False)
CAT={p['id']:p for p in json.loads((OUT/'public-products.json').read_text(encoding='utf8'))}
sessions={};ACTIVE=None
def stamp():return datetime.now(utc.utc).isoformat()
def append(name,row):
 with (OUT/name).open('a',encoding='utf8') as f:f.write(json.dumps(row,ensure_ascii=False,default=str)+'\n')
original_http=httpx.Client.send
def http_send(client,request,*args,**kwargs):
 start=time.perf_counter();body=json.loads(request.content) if request.content else {};record={'arm':ARM,'case_id':ACTIVE['id'] if ACTIVE else None,'started_at':stamp()}
 try:
  if 'deepseek' in request.url.host:
   record['request_options']={k:body.get(k) for k in ['model','thinking','max_tokens','max_completion_tokens','response_format']}
   record['schema']=body['tools'][0]['function']['name'] if body.get('tools') else None
   if not record['schema'] and body.get('messages') and 'JSON Schema' in str(body['messages'][0].get('content','')):
    record['schema']=json.loads(body['messages'][0]['content'].split('\n',1)[1]).get('title')
   record['sensitive_input_hits']=[s for s in ['13900001234','eval.customer@example.invalid'] if s in request.content.decode('utf8')]
  response=original_http(client,request,*args,**kwargs)
  if 'deepseek' in request.url.host:
   payload=json.loads(response.read());record.update(http_status=response.status_code,usage=payload.get('usage',{}),provider_model=payload.get('model'),response_id=payload.get('id'))
   ACTIVE['api'].append(record)
  return response
 except Exception as e:
  record['error_type']=type(e).__name__
  if ACTIVE:ACTIVE['api'].append(record)
  raise
 finally:
  record['seconds']=round(time.perf_counter()-start,6)
  if 'deepseek' in request.url.host:append('api-calls.jsonl',record)
httpx.Client.send=http_send
original_requests=requests.Session.send
def local_send(client,request,**kw):
 start=time.perf_counter();r={'arm':ARM,'case_id':ACTIVE['id'] if ACTIVE else None,'service':'rerank' if 'rerank' in request.url else 'embedding','started_at':stamp()}
 try:
  response=original_requests(client,request,**kw);r['http_status']=response.status_code;return response
 except Exception as e:r['error_type']=type(e).__name__;raise
 finally:
  r['seconds']=round(time.perf_counter()-start,6)
  if ACTIVE:ACTIVE['local'].append(r);append('local-calls.jsonl',r)
requests.Session.send=local_send
import support_ai.retrieval as retrieval
real_search=retrieval.search_knowledge
def public_search(embedding,space_key,owner_id,limit=5):
 assert owner_id is None,'Only public knowledge is authorized'
 return real_search(embedding,space_key,None,limit)
retrieval.search_knowledge=public_search
def judge(c,state,history):
 r=state['response'];cards=r.get('recommendations',[]);tools=state.get('tool_results',[]);s=c['checks'];answer=r.get('answer','');checks={'nonempty':bool(answer.strip())}
 checks['catalog_identity']=all(p.get('sku_id') in CAT for p in cards)
 checks['catalog_price_stock']=all(str(p.get('price'))==CAT[p['sku_id']]['price'] and p.get('available_stock')==CAT[p['sku_id']]['stock'] for p in cards if p.get('sku_id') in CAT)
 checks['private_fields_absent']=not any(k in json.dumps(r,ensure_ascii=False) for k in ['receiver_mobile','cost_price','13900001234','eval.customer@example.invalid'])
 if 'cards_min' in s:checks['cards_min']=len(cards)>=s['cards_min']
 if 'cards_max' in s:checks['cards_max']=len(cards)<=s['cards_max']
 if s.get('category'):checks['category']=bool(cards) and all(p['category']==s['category'] for p in cards)
 if s.get('categories'):checks['categories']=bool(cards) and {p['category'] for p in cards}==set(s['categories'])
 if s.get('excluded'):checks['exclusions']=all(p['category'] not in s['excluded'] for p in cards)
 if s.get('brand'):checks['brand']=bool(cards) and all(CAT[p['sku_id']]['brand']==s['brand'] for p in cards)
 if 'max_price' in s:checks['budget_max']=bool(cards) and all(float(p['price'])<=s['max_price'] for p in cards)
 if 'min_price' in s:checks['budget_min']=bool(cards) and all(float(p['price'])>=s['min_price'] for p in cards)
 if 'total_max' in s:checks['budget_total']=bool(cards) and sum(float(p['price']) for p in cards)<=s['total_max']
 if s.get('no_cards'):checks['no_cards']=not cards
 if s.get('clarify'):checks['clarification']=r.get('clarification_required') is True
 if s.get('knowledge'):checks['knowledge_sources']=bool(r.get('knowledge_sources'))
 if s.get('no_sources'):checks['no_sources']=not r.get('knowledge_sources')
 if s.get('detail_spu'):checks['exact_detail']=any(t['tool']=='get_product_details' and t['status']=='success' and t['data'].get('product_name')==s['detail_spu'] for t in tools)
 if s.get('detail_previous'):
  refs=next((h.get('product_references',[]) for h in reversed(history) if h.get('product_references')),[])
  expected=refs[s['detail_previous']-1]['sku_id'] if len(refs)>=s['detail_previous'] else None
  checks['previous_product']=expected is not None and any(t['tool']=='get_product_details' and t['data'].get('sku_id')==expected for t in tools)
 if 'order_count' in s:checks['order_count']=len(r.get('order_result',{}).get('orders') or [])==s['order_count']
 if 'order_total' in s:checks['order_total']=r.get('order_result',{}).get('total_count')==s['order_total']
 if s.get('answer_contains'):checks['order_status']=s['answer_contains'] in answer
 if s.get('no_write'):
  import re
  checks['no_write_claim']=not bool(re.search(r'(?:已|成功)(?:经)?(?:删除|取消|退款|清空|修改)(?:了|成功|全部|所有|订单|库存)',answer))
 return checks
def ask(c):
 global ACTIVE
 ACTIVE={'id':c['id'],'api':[],'local':[]};start=time.perf_counter();cpu=time.process_time();began=stamp()
 ses=sessions.setdefault(c['session'],{'turns':[],'binding':SimpleNamespace(active_order_id='',active_order_at=None),'page':{}})
 history=context_from_turns(reversed(ses['turns']));retriever=KnowledgeRetriever(None,CONFIG);state=None
 row={'id':c['id'],'arm':ARM,'message':c['message'],'group':c['group'],'comparison':c['comparison'],'mode':c['mode'],'started_at':began,'context_turns':len(history)}
 try:
  user=UserProfile.objects.get(pk=900000+c.get('owner_fixture',1));memory=saved_preferences(user) if c['group']=='长期偏好' else None
  if ARM in ('before','after'):
   from support_ai.order_contracts import prepare_order_input
   from support_ai.order_queries import OrderQueryContext
   message,refs=prepare_order_input(c['message']);oq=OrderQueryContext(owner_id=user.pk,references=refs,active_order_id=ses['binding'].active_order_id,active_order_at=ses['binding'].active_order_at,previous_page=ses['page'])
   order_text='[]'
  else:
   from support_ai.context import current_order_context
   message,order_text,bound=current_order_context(user,ses['binding'],c['message']);oq=None
  def search(q):
   if c['mode']=='kb_timeout':raise TimeoutError('explicit evaluation boundary fault')
   if c['mode']=='kb_empty':return []
   return retriever.search(q)
  def scoped(q,category,scope):
   if c['mode']!='normal':return search(q)
   return retriever.scoped_search(q,category,scope)
  model=configured_model(CONFIG,timeout=45,max_retries=0,max_tokens=4096)
  def factory(st):
   kw=dict(knowledge_context_chars=CONFIG.retrieval_context_chars,scoped_knowledge_search=scoped,knowledge_notes=retriever.notes)
   if ARM in ('before','after'):kw['order_query_context']=oq
   return create_tool_handlers(model,search,st['safe_message'],st['resolved_question'],st.get('recent_turns',[]),memory,order_text,**kw)
  state=workflow.fixed_result(message,history) if hasattr(workflow,'fixed_result') else None
  if state is None:state=build_graph(model,tool_factory=factory).invoke({'message':message,'recent_turns':history,'memory':memory,'owner_id':user.pk})
  r=state['response'];checks=judge(c,state,history)
  row.update(response=r,tool_results=state.get('tool_results',[]),checks=checks,status='passed' if all(checks.values()) else 'failed',safe_message=message)
  ses['turns'].append(SimpleNamespace(pk=c['id'],user_text=message,answer=r['answer'],intent=r['intent'],response=r,created_at=timezone.now()))
  if ARM in ('before','after') and oq.binding_changed:ses['binding']=SimpleNamespace(active_order_id=oq.selected_order_id,active_order_at=timezone.now())
  if ARM=='unused-legacy' and bound:ses['binding']=SimpleNamespace(active_order_id=bound,active_order_at=timezone.now())
  if r.get('order_result'):ses['page']=r['order_result']
 except Exception as exc:
  row.update(status='error',error_type=type(exc).__name__,error_location=[{'file':Path(t.filename).name,'line':t.lineno,'function':t.name} for t in traceback.extract_tb(exc.__traceback__)[-5:]],checks={'completed':False})
 row.update(duration_seconds=round(time.perf_counter()-start,6),client_cpu_seconds=round(time.process_time()-cpu,6),retrieval=retriever.audit,api=ACTIVE['api'],local=ACTIVE['local'])
 append(ARM+'-results.jsonl',row);ACTIVE=None
 return {'id':c['id'],'arm':ARM,'status':row['status'],'failed_checks':[k for k,v in row['checks'].items() if not v],'seconds':row['duration_seconds'],'calls':len(row['api'])}
ctypes.windll.kernel32.SetThreadExecutionState(0x80000001)
try:
 with transaction.atomic(using='ai_storage'):
  with connections['ai_storage'].cursor() as cur:
   cur.execute('SET TRANSACTION ISOLATION LEVEL REPEATABLE READ READ ONLY')
   if os.environ.get('EVAL_PG_SNAPSHOT'):cur.execute("SET TRANSACTION SNAPSHOT '%s'"%os.environ['EVAL_PG_SNAPSHOT'])
   cur.execute('SELECT pg_export_snapshot()');snapshot=cur.fetchone()[0]
  from ai_storage.models import KnowledgeChunk
  public=list(KnowledgeChunk.objects.filter(document__visibility='public',document__status='published',embedding__isnull=False).order_by('pk').values_list('pk','text'))
  digest=hashlib.sha256(json.dumps(public,ensure_ascii=False).encode('utf8')).hexdigest()
  print(json.dumps({'ready':ARM,'snapshot':snapshot,'public_corpus_sha256':digest,'public_chunks':len(public)}),flush=True)
  for line in sys.stdin:
   command=json.loads(line)
   if command.get('stop'):break
   result=ask(command);print(json.dumps(result),flush=True)
finally:
 ctypes.windll.kernel32.SetThreadExecutionState(0x80000000);connections.close_all()
