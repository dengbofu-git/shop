from ai_storage.router import AiStorageRouter
class EvalRouter(AiStorageRouter):
 def db_for_read(self,model,**hints):
  return 'memory_eval' if model._meta.label_lower=='ai_storage.buyermemory' else super().db_for_read(model,**hints)
 def db_for_write(self,model,**hints):
  return 'memory_eval' if model._meta.label_lower=='ai_storage.buyermemory' else super().db_for_write(model,**hints)
 def allow_migrate(self,db,app_label,model_name=None,**hints):
  if db=='memory_eval':return False
  return super().allow_migrate(db,app_label,model_name,**hints)
