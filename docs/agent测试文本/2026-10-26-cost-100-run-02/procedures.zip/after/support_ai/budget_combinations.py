"""Bounded, deterministic bundle search. No ORM, model calls or floating money."""
from dataclasses import dataclass
from time import monotonic


MAX_CANDIDATES = 40
MAX_NODES = 120000
MAX_SECONDS = 2.0
POOL_SIZE = 64
AUTO_MAX_QUANTITY = 5
BEAM_WIDTH = 96


@dataclass(frozen=True)
class Candidate:
    sku_id: int
    product_id: int
    category: str
    price_cents: int
    available_quantity: int
    preference_score: int = 0


def search_bundles(candidates, *, budget_cents, minimum_cents=0, categories=(),
                   quantity=None, distinct_count=None, preference_max=0, prefer_near=False):
    """Bounded beam search over product AND quantity; all amounts are cents."""
    if (type(budget_cents) is not int or budget_cents <= 0
            or type(minimum_cents) is not int or not 0 <= minimum_cents <= budget_cents
            or (quantity is not None and (type(quantity) is not int or not 1 <= quantity <= 100))
            or (distinct_count is not None and (type(distinct_count) is not int or not 1 <= distinct_count <= 4))
            or len(candidates) > MAX_CANDIDATES):
        raise ValueError('Invalid bundle search bounds')
    if len({c.sku_id for c in candidates}) != len(candidates):
        raise ValueError('Duplicate bundle candidate')
    if any(type(value) is not int for c in candidates for value in (
            c.sku_id, c.product_id, c.price_cents, c.available_quantity, c.preference_score)):
        raise ValueError('Bundle candidate money and quantities must be integers')
    required = frozenset(categories)
    low_count = distinct_count if distinct_count is not None else 1
    high_count = distinct_count if distinct_count is not None else 4
    near_floor = max(minimum_cents, (budget_cents * 95 + 99) // 100)
    minimum_quantity = quantity if quantity is not None else 1
    items = sorted((c for c in candidates if c.price_cents > 0
                    and c.available_quantity >= minimum_quantity
                    and c.price_cents * minimum_quantity <= budget_cents),
                   key=lambda c: (c.price_cents, c.sku_id))
    suffix_categories = [frozenset() for _ in range(len(items) + 1)]
    for i in range(len(items) - 1, -1, -1):
        suffix_categories[i] = suffix_categories[i + 1] | {items[i].category}
    pool = {}
    nodes, valid = 0, 0
    stopped, pruned = False, False
    started = monotonic()
    # State: selected (candidate, quantity) pairs, product IDs, categories, total.
    beams = {0: [((), frozenset(), frozenset(), 0)]}

    def ranking(state):
        selected, _, covered, total = state
        count = len(selected)
        preference = (sum(c.preference_score for c, _ in selected) * 100 // (preference_max * count)
                      if preference_max else 100)
        diversity = len(covered) * 100 // count
        quality = (80 * preference + 20 * diversity) // 100
        signature = tuple(sorted((c.sku_id, q) for c, q in selected))
        tail = (-quality, budget_cents - total, sum(q for _, q in selected), count, signature)
        return ((0 if total >= near_floor else 1,) + tail if prefer_near else tail), quality, signature

    def retain(states):
        nonlocal pruned
        if len(states) <= BEAM_WIDTH:
            return states
        pruned = True
        buckets = {}
        for state in states:
            key = (tuple(sorted(state[2] & required)), min(7, state[3] * 8 // budget_cents))
            buckets.setdefault(key, []).append(state)
        for values in buckets.values():
            values.sort(key=lambda s: ranking(s)[0])
        keys = sorted(buckets, key=lambda k: (-len(k[0]), -k[1], k[0]))
        kept = []
        for i in range(BEAM_WIDTH):
            for key in keys:
                if i < len(buckets[key]):
                    kept.append(buckets[key][i])
                    if len(kept) == BEAM_WIDTH:
                        return kept
        return kept

    for index, candidate in enumerate(items):
        for count in range(high_count, 0, -1):
            generated = []
            for state in beams.get(count - 1, []):
                selected, product_ids, covered, total = state
                if candidate.product_id in product_ids:
                    continue
                ceiling = min(candidate.available_quantity, (budget_cents - total) // candidate.price_cents,
                              quantity if quantity is not None else AUTO_MAX_QUANTITY)
                choices = [quantity] if quantity is not None and quantity <= ceiling else (
                    range(1, ceiling + 1) if quantity is None else [])
                for units in choices:
                    nodes += 1
                    if nodes > MAX_NODES or (nodes % 128 == 0 and monotonic() - started >= MAX_SECONDS):
                        stopped = True
                        break
                    next_state = (selected + ((candidate, units),), product_ids | {candidate.product_id},
                                  covered | {candidate.category}, total + candidate.price_cents * units)
                    rank, quality, signature = ranking(next_state)
                    if count >= low_count and next_state[3] >= minimum_cents and required <= next_state[2]:
                        valid += 1
                        pool[signature] = (rank, signature, next_state[3], quality)
                        if len(pool) > POOL_SIZE:
                            worst = max(pool, key=lambda key: pool[key][0])
                            del pool[worst]
                    missing = required - next_state[2]
                    if (count < high_count and len(missing) <= high_count - count
                            and missing <= suffix_categories[index + 1]):
                        generated.append(next_state)
                if stopped:
                    break
            beams[count] = retain(beams.get(count, []) + generated)
            if stopped:
                break
        if stopped:
            break
    ordered = sorted(pool.values(), key=lambda row: row[0])
    return {
        'plans': [{'sku_ids': [pk for pk, _ in signature], 'quantities': [q for _, q in signature],
                   'subtotal_cents': total, 'quality_score': quality,
                   'near_budget': total >= near_floor} for _, signature, total, quality in ordered],
        'nodes': nodes, 'valid_combinations': valid, 'search_complete': not stopped and not pruned,
        'candidate_count': len(items), 'near_floor_cents': near_floor,
        'quantity_mode': 'fixed' if quantity is not None else 'automatic',
        'automatic_quantity_cap': AUTO_MAX_QUANTITY, 'beam_width': BEAM_WIDTH,
    }
