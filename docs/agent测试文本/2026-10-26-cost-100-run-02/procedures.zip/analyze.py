# -*- coding: utf-8 -*-
import json,statistics,math,hashlib,zipfile,sqlite3
from pathlib import Path
from collections import Counter
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1];OUT=ROOT/'docs/agent测试文本/2026-10-26-cost-100-run-02'
OLD=ROOT/'docs/agent测试文本/2026-10-26-real-100-run-01'
def load(n):return json.loads((OUT/n).read_text(encoding='utf8'))
def lines(n):return [json.loads(s) for s in (OUT/n).read_text(encoding='utf8').splitlines()]
def save(n,v):(OUT/n).write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
def percentile(v,p):
 v=sorted(v);i=(len(v)-1)*p;lo=int(i);hi=min(lo+1,len(v)-1);return v[lo]+(v[hi]-v[lo])*(i-lo)
def stats(v):return {'mean':statistics.mean(v),'p50':percentile(v,.5),'p95':percentile(v,.95),'max':max(v)} if v else None
def usage(calls):
 s={k:0 for k in ['calls','input_tokens','output_tokens','reasoning_tokens','cache_hit_tokens','cache_miss_tokens','missing_usage']}
 for c in calls:
  u=c.get('usage',{});s['calls']+=1;s['missing_usage']+=not bool(u)
  s['input_tokens']+=u.get('prompt_tokens',0);s['output_tokens']+=u.get('completion_tokens',0)
  s['reasoning_tokens']+=(u.get('completion_tokens_details') or {}).get('reasoning_tokens',0)
  hit=u.get('prompt_cache_hit_tokens',(u.get('prompt_tokens_details') or {}).get('cached_tokens',0));s['cache_hit_tokens']+=hit;s['cache_miss_tokens']+=u.get('prompt_cache_miss_tokens',u.get('prompt_tokens',0)-hit)
 s['cost_usd_offpeak']=(s['cache_hit_tokens']*.003+s['cache_miss_tokens']*.15+s['output_tokens']*.6)/1e6
 s['cost_usd_peak']=s['cost_usd_offpeak']*2
 return s
cases=load('cases-100.json');case_map={c['id']:c for c in cases};arms=['before','after']
rows={a:lines(a+'-results.jsonl') for a in arms}
assert all(len(rs)==100 and [r['id'] for r in rs]==['R%03d'%i for i in range(1,101)] for rs in rows.values())
review=load('manual-review.json') if (OUT/'manual-review.json').exists() else {}
def verdict(a,r):return review.get(a,{}).get(r['id'],{}).get('pass',r['status']=='passed')
summary={}
for a,rs in rows.items():
 calls=[c for r in rs for c in r['api']];local=[c for r in rs for c in r['local']]
 summary[a]={'total':100,'automatic_pass':sum(r['status']=='passed' for r in rs),'reviewed_pass':sum(verdict(a,r) for r in rs),'uncaught_errors':sum(r['status']=='error' for r in rs),'review_entries':len(review.get(a,{})), 'usage':usage(calls),'latency_seconds':stats([r['duration_seconds'] for r in rs]),'model_path_latency':stats([r['duration_seconds'] for r in rs if r['api']]),'rule_path_latency':stats([r['duration_seconds'] for r in rs if not r['api']]),'model_calls_per_turn':stats([len(r['api']) for r in rs]),'groups':{},'schemas':{},'local':{},'http_statuses':dict(Counter(str(c.get('http_status',c.get('error_type'))) for c in calls)),'budget_errors':[r['id'] for r in rs if r.get('error_type')=='ModelBudgetExceeded' or any(t['data'].get('error_type')=='ModelBudgetExceeded' for t in r.get('tool_results',[]))],'sensitive_prompt_hits':[c['case_id'] for c in calls if c.get('sensitive_input_hits')]}
 for g in dict.fromkeys(c['group'] for c in cases):
  selected=[r for r in rs if r['group']==g];summary[a]['groups'][g]={'count':len(selected),'automatic_pass':sum(r['status']=='passed' for r in selected),'reviewed_pass':sum(verdict(a,r) for r in selected),'latency_seconds':stats([r['duration_seconds'] for r in selected]),'usage':usage([c for r in selected for c in r['api']])}
 for name in dict.fromkeys(c.get('schema') or 'unknown' for c in calls):summary[a]['schemas'][name]=usage([c for c in calls if (c.get('schema') or 'unknown')==name])
 for svc in ['embedding','rerank']:
  selected=[c for c in local if c['service']==svc];summary[a]['local'][svc]={'calls':len(selected),'http_statuses':dict(Counter(str(c.get('http_status',c.get('error_type'))) for c in selected)),'latency_seconds':stats([c['seconds'] for c in selected])}
pairs=[]
for b,n in zip(rows['before'],rows['after']):
 bu=usage(b['api']);nu=usage(n['api']);pairs.append({'id':b['id'],'before_pass':verdict('before',b),'after_pass':verdict('after',n),'before_seconds':b['duration_seconds'],'after_seconds':n['duration_seconds'],'before_peak_usd':bu['cost_usd_peak'],'after_peak_usd':nu['cost_usd_peak'],'seconds_delta':n['duration_seconds']-b['duration_seconds'],'peak_usd_delta':nu['cost_usd_peak']-bu['cost_usd_peak']})
summary['paired_changes']={'improved':[p['id'] for p in pairs if p['after_pass'] and not p['before_pass']],'regressed':[p['id'] for p in pairs if p['before_pass'] and not p['after_pass']],'same_pass':sum(p['before_pass'] and p['after_pass'] for p in pairs),'same_fail':sum(not p['before_pass'] and not p['after_pass'] for p in pairs)}
save('summary.json',summary);save('paired-changes.json',pairs)
prior=json.loads((ROOT/'reports/agent-evaluation/2026-10-26-rerank-query-ab/run-2/cases.json').read_text(encoding='utf8'));rag={}
for arm,rs in rows.items():
 records=[]
 for c,label in zip(cases[40:55],prior):
  r=next(v for v in rs if v['id']==c['id']);ids=list(dict.fromkeys(int(v) for audit in r['retrieval'] for v in audit.get('selected_ids',[])));relevant=set(label['relevant_ids']);groups=label['support_groups'];grades=label['grades']
  dcg=lambda values:sum((2**g-1)/math.log2(i+2) for i,g in enumerate(values))
  ideal=dcg(sorted(grades.values(),reverse=True)[:5]);gains=[grades.get(str(v),0) for v in ids[:5]]
  records.append({'id':c['id'],'selected_ids':ids,'precision':len(set(ids)&relevant)/len(ids) if ids else 0,'coverage':sum(bool(set(g)&set(ids)) for g in groups)/len(groups) if groups else None,'ndcg_at_5':dcg(gains)/ideal if ideal else None})
 rag[arm]={'mean_precision':statistics.mean(r['precision'] for r in records),'mean_coverage':statistics.mean(r['coverage'] for r in records if r['coverage'] is not None),'mean_ndcg_at_5':statistics.mean(r['ndcg_at_5'] for r in records if r['ndcg_at_5'] is not None),'cases':records}
save('retrieval-quality.json',rag)
detail=['# 同题100条成本控制前后实际记录','','每题两组均为本轮实际执行，使用相同最新业务代码；before只撤回成本控制。完整结构化字段及调用usage保存在before-results.jsonl和after-results.jsonl。','']
for c in cases:
 detail+=['## '+c['id']+' · '+c['group'],'',c['message'],'','预期：`'+json.dumps(c['checks'],ensure_ascii=False)+'`','']
 for a,label in [('before','成本控制前'),('after','成本控制后')]:
  r=next(v for v in rows[a] if v['id']==c['id']);u=usage(r['api']);rv=review.get(a,{}).get(c['id']);detail+=['### '+label+'：'+('通过' if verdict(a,r) else '未通过'),'',r.get('response',{}).get('answer','运行异常：'+r.get('error_type','unknown')),'',f"耗时{r['duration_seconds']:.3f}s；模型请求{u['calls']}次；输入/输出Token {u['input_tokens']}/{u['output_tokens']}，其中思考{u['reasoning_tokens']}；已知usage费用估算USD ${u['cost_usd_offpeak']:.6f}–${u['cost_usd_peak']:.6f}。",'','原始自动检查：`'+json.dumps(r['checks'],ensure_ascii=False)+'`','']
  if rv:detail+=['人工复核：'+rv['reason'],'']
(OUT/'逐条实际记录.md').write_text('\n'.join(detail),encoding='utf8')
b=summary['before'];n=summary['after'];reduction=lambda new,old:(1-new/old)*100 if old else None
table=['| 指标 | 成本控制前 | 成本控制后 |','|---|---:|---:|']
for label,fn in [('自动约束通过数',lambda s:str(s['automatic_pass'])+'/100'),('复核后通过数',lambda s:str(s['reviewed_pass'])+'/100'),('平均耗时',lambda s:'%.3fs'%s['latency_seconds']['mean']),('P50耗时',lambda s:'%.3fs'%s['latency_seconds']['p50']),('P95耗时',lambda s:'%.3fs'%s['latency_seconds']['p95']),('模型请求次数',lambda s:str(s['usage']['calls'])),('输入Token',lambda s:str(s['usage']['input_tokens'])),('输出Token（包含思考）',lambda s:str(s['usage']['output_tokens'])),('思考Token',lambda s:str(s['usage']['reasoning_tokens'])),('未返回usage调用',lambda s:str(s['usage']['missing_usage'])),('API已知用量费用USD',lambda s:'$%.6f–$%.6f'%(s['usage']['cost_usd_offpeak'],s['usage']['cost_usd_peak']))]:table.append('| '+label+' | '+fn(b)+' | '+fn(n)+' |')
report=['# 同题100条：成本控制前后结果、成本与性能','','本轮两组各100条，直接比较同一份最新业务代码中撤回/启用本次成本控制的差别；两组同日交替AB/BA执行。保留旧报告，未用新数据覆盖历史结果。','',*table,'',f"按同价口径，已知usage对应API费用减少{reduction(n['usage']['cost_usd_peak'],b['usage']['cost_usd_peak']):.1f}%，平均耗时减少{reduction(n['latency_seconds']['mean'],b['latency_seconds']['mean']):.1f}%，P95减少{reduction(n['latency_seconds']['p95'],b['latency_seconds']['p95']):.1f}%。真实回答质量见复核和退步清单，不能仅因费用下降认定优化成功。",'','## 控制变量和范围','','- 输入为上一轮完全相同的100条问题、115个公开可售SKU快照、27笔合成订单、隔离红茶偏好；会话顺序相同。长期偏好仅5条专项输入，其他图输入为None。数据仍使用SQLite隔离，不读真实买家历史、订单或偏好。','- 两组冻结相同当前业务代码和全部本地Python依赖源码；仅6个成本相关文件不同：模型适配、知识/茶类重试、执行器预算提示、组合审核和图请求预算接入。before为同业务的反事实对照，非旧部署复刻。精确源码差异见source-manifest.json。','- 使用同一PostgreSQL REPEATABLE READ READ ONLY共享快照，所有检索强制owner=None，仅公开已发布知识。真实Ollama嵌入、pgvector召回、RRF、重排和模型链路；未修改生产服务与数据库。','- 全局模型配置沿用上轮deepseek-flash、thinking=enabled、revision=5、temperature=0、调用方timeout=45、SDK重试0、调用方max_tokens=4096；优化组再按本次阶段策略及请求预算收紧。before实际开启thinking，after六阶段均关闭；实际HTTP参数与usage逐次记录，不以全局配置字符串替代实际开关。','- before恢复旧适配器的max_completion_tokens发送方式、thinking及重试/复核流程，after采用max_tokens和分阶段开关；比较的是本次成本控制整体，不能归因于其中单独一个改动。','- 图与工具集成测试，包含按条构建模型客户端开销；不是浏览器、HTTP提交/重放、数据库吞吐或独占硬件压测。本地服务与外部模型仍受负载、缓存和服务预算影响。','- 自动约束与人工复核分别保留；知识事实以冻结片段为依据，不是独立专家/外部世界事实审核。超时、错误、澄清和退步均计入，不用重试替换失败记录。每题每组一次，未重复多轮；thinking模式不保证temperature=0生效，不能宣称完全确定性。','', '## 分场景结果','','| 场景 | 数量 | 前/后复核通过 | 前/后平均耗时 | 前/后模型调用 |','|---|---:|---:|---:|---:|']
for g,x in b['groups'].items():
 y=n['groups'][g];report.append('| '+g+' | '+str(x['count'])+' | %s / %s | %.3fs / %.3fs | %s / %s |'%(x['reviewed_pass'],y['reviewed_pass'],x['latency_seconds']['mean'],y['latency_seconds']['mean'],x['usage']['calls'],y['usage']['calls']))
report+=['','## 分阶段模型费用','','| 结构化阶段 | 前/后调用数 | 前/后已知峰时费用USD |','|---|---:|---:|']
for name in dict.fromkeys([*b['schemas'],*n['schemas']]):
 x=b['schemas'].get(name,usage([]));y=n['schemas'].get(name,usage([]));report.append('| '+str(name)+' | %s / %s | $%.6f / $%.6f |'%(x['calls'],y['calls'],x['cost_usd_peak'],y['cost_usd_peak']))
report+=['','## 检索相关性','','15条预标注知识子集按实际最终证据评估；相关精度含15题，覆盖率和nDCG含14条可评分题，虚构配方不硬填零。多任务证据按请求顺序合并去重，不是单独重排消融。','','| 指标 | 前 | 后 |','|---|---:|---:|']
for k,label in [('mean_precision','直接相关证据精度'),('mean_coverage','证据组覆盖率'),('mean_ndcg_at_5','nDCG@5')]:report.append('| '+label+' | %.4f | %.4f |'%(rag['before'][k],rag['after'][k]))
report+=['','## 质量变化与限制','','进步：'+(', '.join(summary['paired_changes']['improved']) or '无')+'。','退步：'+(', '.join(summary['paired_changes']['regressed']) or '无')+'。','']
for a,label in [('after','优化后'),('before','对照前')]:
 report+=['### '+label+'未通过项','']
 for r in rows[a]:
  if not verdict(a,r):report.append('- '+r['id']+'：'+review.get(a,{}).get(r['id'],{}).get('reason','未通过 '+', '.join(k for k,v in r['checks'].items() if not v)))
report+=['','## 与上一轮历史结果的区别','','上一轮冻结快照与本轮还存在其他推荐/预算业务改动；该历史比较只能作为观察，不能用于单独归因本次成本控制。旧报告保留：[优化前100条](../2026-10-26-real-100-run-01/测试报告.md)。','','## 费用口径','','使用HTTP实际usage的缓存命中、未命中及输出Token分别计价，思考已包含在输出中不重复计费。依据DeepSeek官方每百万Token非峰时缓存命中$0.003、未命中$0.15、输出$0.6，峰时两倍。表中范围为同一用量按两种时段计价；缺失usage请求可能仍实扣，不构成完整账单上下界。本地嵌入/重排无新增按Token API费，但硬件和用电成本未折算。来源：[DeepSeek官方价格](https://api-docs.deepseek.com/quick_start/pricing/)。','','本地服务状态和耗时见summary.json；429、客户端超时及降级保持原记录，不能声称是无噪声的纯算法基准。模型平台缓存跨组共享、AB/BA交替只能降低顺序偏差，不能消除所有波动。','', '## 复核文件','','- cases-100.json：完全相同的冻结问题和检查。','- before-results.jsonl / after-results.jsonl：完整实际响应、工具结果、预算诊断、检索审计及调用用量。','- 逐条实际记录.md：100组双版本实际答复与费用耗时。','- api-calls.jsonl：实际开关、输出参数、结构化阶段、HTTP状态、usage；不含密钥或思考正文。','- local-calls.jsonl：嵌入/重排实际请求与耗时。','- manual-review.json / paired-changes.json：人工复核、改善与退步。','- source-manifest.json / integrity.json / procedures.zip：输入、源码、脚本与完整性。','', '本轮仅测试与生成证据，未提交、推送、部署或修改业务实现。']
(OUT/'测试报告.md').write_text('\n'.join(report)+'\n',encoding='utf8')
manifest=load('source-manifest.json');integrity={'records':{a:len(rs) for a,rs in rows.items()},'frozen_sources_unchanged':{},'shared_sources_unchanged':True,'inputs_unchanged':all(hashlib.sha256((OUT/k).read_bytes()).hexdigest()==h for k,h in manifest['frozen_inputs_sha256'].items()),'api_log_calls':len(lines('api-calls.jsonl')),'row_api_calls':sum(len(r['api']) for rs in rows.values() for r in rs),'fixture_unchanged':{}}
for a in arms:
 integrity['frozen_sources_unchanged'][a]=all(hashlib.sha256((HERE/a/k).read_bytes()).hexdigest()==h for k,h in manifest['source_sha256'][a].items())
for k,h in manifest['shared_source_sha256'].items():integrity['shared_sources_unchanged'] &= hashlib.sha256((HERE/'shared'/k).read_bytes()).hexdigest()==h
for name,h in manifest['fixture_sha256'].items():integrity['fixture_unchanged'][name]=hashlib.sha256((HERE/name).read_bytes()).hexdigest()==h
assert all(integrity['frozen_sources_unchanged'].values()) and integrity['shared_sources_unchanged'] and integrity['inputs_unchanged'] and all(integrity['fixture_unchanged'].values()) and integrity['api_log_calls']==integrity['row_api_calls']
save('integrity.json',integrity)
with zipfile.ZipFile(OUT/'procedures.zip','w',zipfile.ZIP_DEFLATED) as z:
 for f in HERE.rglob('*'):
  if f.is_file() and f.suffix in ('.py','.json') and '__pycache__' not in f.parts:z.write(f,str(f.relative_to(HERE)))
save('file-sha256.json',{f.name:hashlib.sha256(f.read_bytes()).hexdigest() for f in OUT.iterdir() if f.is_file() and f.name not in ['file-sha256.json','review-working.txt']})
print(json.dumps({'summary':summary,'rag':{a:{k:v for k,v in d.items() if k!='cases'} for a,d in rag.items()},'integrity':integrity},ensure_ascii=True))
