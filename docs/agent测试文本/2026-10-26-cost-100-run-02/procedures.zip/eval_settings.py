from tea_saas.settings import *
from pathlib import Path
import os
EVAL_ROOT=Path(__file__).parent
DATABASES['default']={'ENGINE':'django.db.backends.sqlite3','NAME':str(EVAL_ROOT/os.environ.get('EVAL_DB','fixtures.sqlite3'))}
DATABASES['memory_eval']={'ENGINE':'django.db.backends.sqlite3','NAME':str(EVAL_ROOT/'memory.sqlite3')}
CACHES={'default':{'BACKEND':'django.core.cache.backends.locmem.LocMemCache'},'carts':{'BACKEND':'django.core.cache.backends.locmem.LocMemCache'}}
DATABASE_ROUTERS=['eval_router.EvalRouter']
ALLOWED_HOSTS=['testserver','127.0.0.1']
