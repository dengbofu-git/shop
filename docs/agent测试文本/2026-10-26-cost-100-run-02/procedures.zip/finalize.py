# -*- coding: utf-8 -*-
import json,hashlib,zipfile,shutil
from pathlib import Path
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1];OUT=ROOT/'docs/agent测试文本/2026-10-26-cost-100-run-02'
def load(n):return json.loads((OUT/n).read_text(encoding='utf8'))
def save(n,v):(OUT/n).write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
data={a:[json.loads(v) for v in (OUT/(a+'-results.jsonl')).read_text(encoding='utf8').splitlines()] for a in ['before','after']}
s=load('summary.json');b=s['before'];a=s['after'];review=load('manual-review.json')
def calls_cost(calls):
 hit=miss=out=0
 for call in calls:
  u=call.get('usage',{});h=u.get('prompt_cache_hit_tokens',(u.get('prompt_tokens_details') or {}).get('cached_tokens',0));hit+=h;miss+=u.get('prompt_cache_miss_tokens',u.get('prompt_tokens',0)-h);out+=u.get('completion_tokens',0)
 return (hit*.003+miss*.15+out*.6)/1e6
common_embedding_failures=[]
for before,after in zip(data['before'],data['after']):
 def all_failed(row):
  route=[q for audit in row['retrieval'] for q in audit.get('queries',[]) if q['status']!='request_budget']
  return bool(route) and all(q.get('error_type')=='ReadTimeout' and q.get('hits')==0 for q in route) and not any(v.get('selected_ids') for v in row['retrieval'])
 if all_failed(before) and all_failed(after):common_embedding_failures.append(before['id'])
sensitivity={}
for arm,rows in data.items():
 selected=[r for r in rows if r['id'] not in common_embedding_failures]
 sensitivity[arm]={'total':len(selected),'reviewed_pass':sum(review.get(arm,{}).get(r['id'],{}).get('pass',r['status']=='passed') for r in selected),'mean_seconds':sum(r['duration_seconds'] for r in selected)/len(selected),'known_usage_cost_offpeak':calls_cost([c for r in selected for c in r['api']])}
save('sensitivity.json',{'scope':'Post-hoc sensitivity excluding only cases with both arms all embedding routes timing out and no evidence; raw 100-case main result retained','excluded_common_embedding_failure_ids':common_embedding_failures,'groups':sensitivity})
knowledge={}
for arm in ['before','after']:
 entries=[review[arm]['R%03d'%i] for i in range(41,61)]
 knowledge[arm]={'reviewed':20,'core_correct':sum(v.get('core_correct',v['pass']) for v in entries),'strict_pass':sum(v['pass'] for v in entries),'unsupported_claim_cases':sum(v.get('grounded') is False for v in entries)}
save('knowledge-review-summary.json',knowledge)
report=OUT/'测试报告.md';text=report.read_text(encoding='utf8')
intro=("## 本次结论\n\n"
 "成本控制有效降低了本样本开销，但不能认定质量无损。相同业务、同日配对的已知usage费用从每100条$0.120208–$0.240416降到$0.026314–$0.052628，减少78.1%；平均耗时16.823s降至6.771s，减少59.8%；P95从72.662s降到26.332s，减少63.8%。\n\n"
 "原自动约束两组均83/100；按相同标准逐条复核重点答复后，对照75/100、优化74/100，改善3条、退步4条。自动总分不变掩盖了具体回退，不能只看通过率或只看费用。\n\n"
 "- 改善：R045补足阿联酋习俗资料缺口说明；R051完成CTC/Orthodox回答，避免长时间后失败；R054恢复有证据的冲泡参数说明。\n"
 "- 回退：R018排除绿茶/红茶的语义证据校验失败；R026送礼请求没有产出商品；R048/R052将“稍后供茶”具体化成“餐后供茶”，核验漏检。R046优化后同样出现该时间越界，但对照本身服务失败，严格判分两边均未过，不列为新增回退。\n"
 "- R018仅输出305 Token，远未达到1400的规划上限；预算拒绝次数为0，明确诊断为“意向条件无法对应输入证据”。这不是本轮Token预算截断所致。\n"
 "- R028优化后虽恢复推荐与理由，附加六类茶说明却把black tea误译，列表出现两个“黑茶”。与对照的全局误拒绝一样，整条都未通过；不能把商品卡存在当成回答准确。\n\n"
 "模型请求178降到132；其中通用合规复核36降到0、知识草稿30降到23、语义核验23降到20；意图规划55次及查询改写34次均未减少。思考Token从150557降到0，非思考输出反而从26753略增到27213，说明主要省掉的是思考和重复处理，并非简单缩短用户答案。没有请求级模型预算耗尽，优化组API全部132次200且均返回usage；对照4次缺失usage，潜在实扣不在费用表中。\n\n"
 "建议保留预算、参数修正及减少重复审核，但不要仅凭本轮费用下降就宣称全阶段关闭thinking可以无损替代。后续应对规划证据绑定、语义核验的时间/茶类翻译边界单独改进或小样本比较；本轮未调整代码来追求更好的分数。\n\n")
first,rest=text.split('\n',1);text=first+'\n\n'+intro+rest.lstrip('\n')
block=['## 基础服务故障与敏感性分析','', 'R069、R070、R092两组都出现本地embedding的全部召回路由ReadTimeout，零证据返回；每组9次embedding超时。它们不是模型预算拒绝或PostgreSQL事务失败。原始100条仍全部计入。事后仅排除这3条共同故障的97条敏感性统计如下，不替代主统计：','','| 97条共同非故障子集 | 前 | 后 |','|---|---:|---:|']
block.append('| 复核通过 | %s/97 | %s/97 |'%(sensitivity['before']['reviewed_pass'],sensitivity['after']['reviewed_pass']))
block.append('| 平均耗时 | %.3fs | %.3fs |'%(sensitivity['before']['mean_seconds'],sensitivity['after']['mean_seconds']))
block.append('| 已知usage非峰时费用USD | $%.6f | $%.6f |'%(sensitivity['before']['known_usage_cost_offpeak'],sensitivity['after']['known_usage_cost_offpeak']))
block+=['','本次无重排429；对照有2次本地重排客户端超时，优化后30次重排均200。模型/服务降级保留原样，不能把失去知识生成的请求当成降费成功。','']
text=text.replace('## 质量变化与限制','\n'.join(block)+'\n## 质量变化与限制')
old=json.loads((ROOT/'docs/agent测试文本/2026-10-26-real-100-run-01/summary.json').read_text(encoding='utf8'))['current']
hist=['| 口径 | 旧历史冻结快照 | 本轮同业务对照 | 本轮成本控制后 |','|---|---:|---:|---:|', '| 复核通过 | 69/100 | 75/100 | 74/100 |', '| 平均耗时 | %.3fs | %.3fs | %.3fs |'%(old['latency_seconds']['mean'],b['latency_seconds']['mean'],a['latency_seconds']['mean']), '| P95耗时 | %.3fs | %.3fs | %.3fs |'%(old['latency_seconds']['p95'],b['latency_seconds']['p95'],a['latency_seconds']['p95']), '| 已知usage费用USD | $%.6f–$%.6f | $%.6f–$%.6f | $%.6f–$%.6f |'%(old['usage']['cost_usd_offpeak'],old['usage']['cost_usd_peak'],b['usage']['cost_usd_offpeak'],b['usage']['cost_usd_peak'],a['usage']['cost_usd_offpeak'],a['usage']['cost_usd_peak']), '']
text=text.replace('## 与上一轮历史结果的区别\n','## 与上一轮历史结果的区别\n\n'+'\n'.join(hist)+'\n')
text=text.replace('## 检索相关性\n','## 检索相关性\n\n本轮15条预标注题的最终选中片段，两组完全一致，nDCG@5均0.8552、覆盖率均1.0、直接相关精度均0.3333。成本与文本质量差异不能解释为该子集选中了不同证据。\n')
text=text.replace('## 费用口径\n','## 费用口径\n\n本轮全部200条完成后，控制器等待工作进程退出30秒超时。完成标记和310次HTTP记录已全部落盘；随后只读检查两个本次Python工作进程已自行退出，无残留，未强制终止或重启数据库/模型服务。该收尾异常不计入单条耗时，保留在cleanup.json。\n')
text+='\n知识专项20条均已复核：核心任务完成对照16/20、优化20/20；若要求附加事实也有支持，则15/20、16/20。该指标混合可回答、资料缺口及防编造场景，不是线上真实用户准确率。优化后4条知识题的附加问题均为同一“稍后→餐后”时间翻译模式，不能看成4次独立实验。其余非知识题只复核所列重点，其他沿用冻结自动约束；没有独立专家盲审。\n'
report.write_text(text,encoding='utf8')
save('cleanup.json',{'cases_completed':200,'completion_marker':load('completion.json'),'controller_exit':'TimeoutExpired waiting for worker after all cases were saved','observed_worker_pids_after_controller_exit':[40388,7080],'follow_up_process_check':'No matching worker processes remained; workers exited naturally before cleanup; no processes stopped','production_services_changed':False})
manifest=load('source-manifest.json');drift=[]
for rel,h in manifest['source_sha256']['after'].items():
 p=ROOT/rel
 if not p.exists() or hashlib.sha256(p.read_bytes()).hexdigest()!=h:drift.append(rel)
save('workspace-drift.json',{'frozen_workspace_version':manifest['workspace_version'],'post_run_workspace_version':json.loads((ROOT/'versions/modules.json').read_text(encoding='utf8'))['modules']['support_ai']['version'],'changed_support_files_since_freeze':drift,'interpretation':'Frozen after/shared source hashes define tested code; subsequent live changes are not validated'})
if drift:
 text=report.read_text(encoding='utf8');head,rest=text.split('\n',1);report.write_text(head+'\n\n**源码范围：** 本轮使用开跑冻结源码；共享工作区运行期间另有'+str(len(drift))+'个Agent源文件变化，见workspace-drift.json，后续变化未纳入本轮。\n'+rest,encoding='utf8')
integrity=load('integrity.json');ids=[c['response_id'] for c in [json.loads(v) for v in (OUT/'api-calls.jsonl').read_text(encoding='utf8').splitlines()] if c.get('response_id')];integrity['api_response_ids_unique']=len(ids)==len(set(ids));integrity['paired_markdown_count']=(OUT/'逐条实际记录.md').read_text(encoding='utf8').count('## R');integrity['sensitive_prompt_hits']=sum(len(row['sensitive_input_hits']) for row in s.values() if isinstance(row,dict) and 'sensitive_input_hits' in row);assert integrity['api_response_ids_unique'] and integrity['paired_markdown_count']==100 and not integrity['sensitive_prompt_hits'];save('integrity.json',integrity)
if (OUT/'review-working.txt').exists():(OUT/'review-working.txt').unlink()
with zipfile.ZipFile(OUT/'procedures.zip','w',zipfile.ZIP_DEFLATED) as z:
 for f in HERE.rglob('*'):
  if f.is_file() and f.suffix in ('.py','.json') and '__pycache__' not in f.parts:z.write(f,str(f.relative_to(HERE)))
save('file-sha256.json',{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in OUT.iterdir() if p.is_file() and p.name!='file-sha256.json'})
print(json.dumps({'knowledge':knowledge,'sensitivity':sensitivity,'shared_infra_failures':common_embedding_failures,'changed_live_source_files':len(drift),'cleanup':'No residual workers'},ensure_ascii=True))
