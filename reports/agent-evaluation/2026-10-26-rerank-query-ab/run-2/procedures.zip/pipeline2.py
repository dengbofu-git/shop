"""Run the same postprocessing against new observations only."""
import ctypes
from pathlib import Path
import sys

HERE=Path(__file__).resolve().parent
mode=sys.argv[1]
script={'count':'count_work.py','analyze':'analyze.py','report':'report2.py'}[mode]
text=(HERE/script).read_text(encoding='utf8')
old="reports/agent-evaluation/2026-10-26-rerank-query-ab/run-1"
if mode!='report':
    assert text.count(old)==1
    text=text.replace(old,old.replace('run-1','run-2'))
ctypes.windll.kernel32.SetThreadExecutionState(0x80000001)
try:exec(compile(text,str(HERE/script),'exec'),{'__name__':'__main__','__file__':str(HERE/script)})
finally:ctypes.windll.kernel32.SetThreadExecutionState(0x80000000)
