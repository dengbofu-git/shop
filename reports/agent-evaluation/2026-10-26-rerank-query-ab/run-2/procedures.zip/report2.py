# coding: utf-8
"""Render run-2 only, using fresh answer reviews and measured observations."""
import csv
import hashlib
import json
from pathlib import Path
import re
import statistics
import zipfile
from datetime import datetime,timezone

ROOT=Path(r'E:\django\dadashop')
OUT=ROOT/'reports/agent-evaluation/2026-10-26-rerank-query-ab/run-2'
HERE=Path(__file__).resolve().parent
def load(name):return json.loads((OUT/name).read_text(encoding='utf8'))
def rows(name):return [json.loads(x) for x in (OUT/name).read_text(encoding='utf8').splitlines()]
def save(name,value):(OUT/name).write_bytes((json.dumps(value,ensure_ascii=False,indent=2)+'\n').encode('utf8'))
s=load('summary.json');manifest=load('manifest.json');cases=load('cases.json');results=rows('rerank-results.jsonl');answers=rows('answers.jsonl')
reviews=load('answer-review.json')['cases']
assert len(results)==90 and len(answers)==30 and len(reviews)==30
review_map={(r['case_id'],r['arm']):r for r in reviews}
qa={}
review_notes='\n'.join(f"- {r['arm']}第{r['case_id']}题：{r['note']}" for r in reviews if not r['grounded'] or not r['core_correct'])
for arm in ('A','B'):
    rr=[r for r in reviews if r['arm']==arm]
    qa[arm]={'core_correct':sum(r['core_correct'] for r in rr),'strict_pass':sum(r['core_correct'] and r['grounded'] and r['citation_valid'] for r in rr),
        'grounded':sum(r['grounded'] for r in rr),'confirmed_factual_errors':sum(r['confirmed_factual_error'] for r in rr),
        'citation_valid':sum(r['citation_valid'] for r in rr)}
s['answer_review']=qa
events=rows('environment-events.jsonl') if (OUT/'environment-events.jsonl').exists() else []
validity=rows('environment-validity.jsonl')
s['environment_validity']={'heartbeat_events':len(events),'requests_marked_invalid':sum(not r['host_timing_valid'] for r in validity),
    'probe_failure':load('run-state.json')['probe_failed'],'keep_awake_released':load('run-state.json')['keep_awake_released']}
s['finished_at']=datetime.now(timezone.utc).isoformat();save('summary.json',s)
A=s['arms']['A'];B=s['arms']['B'];rate=lambda v:f'{v*100:.1f}%'
wall_change=(B['wall_seconds_mean']/A['wall_seconds_mean']-1)*100
cpu_change=(B['cpu_seconds_mean']/A['cpu_seconds_mean']-1)*100
token_change=(B['pair_tokens_padded_mean']/A['pair_tokens_padded_mean']-1)*100
ci=s['paired_quality']['ranking_metrics.ndcg_at_5']['question_bootstrap_95ci']
cost=s['api_cost']['all']['estimated_usd_range']
with (OUT/'answers.md').open('w',encoding='utf8') as f:
    f.write('# Run-2 新生成答案与逐题审核\n\n')
    for c in cases:
        f.write(f"## {c['id']}. {c['scene']}\n\n{c['message']}\n\n")
        for arm in ('A','B'):
            r=next(r for r in answers if r['case_id']==c['id'] and r['arm']==arm);review=review_map[(c['id'],arm)]
            f.write(f"### {arm}\n\n证据：{r['selected_ids']}；第{r['source_repeat']+1}轮成功配对。\n\n{r['text']}\n\n审核：{review['note']}\n\n")
with (OUT/'per-case.csv').open('w',encoding='utf-8-sig',newline='') as f:
    w=csv.writer(f);w.writerow(['id','arm','question','raw_ndcg_at_5','raw_p_at_5','selected_ndcg_at_5','selected_support_coverage','core_correct','grounded','citation_valid','note'])
    for c in s['cases']:
        for arm in ('A','B'):
            r=c['arms'][arm];v=review_map[(c['case_id'],arm)]
            w.writerow([c['case_id'],arm,c['question'],r['ranking_metrics']['ndcg_at_5'],r['ranking_metrics']['precision_at_5_direct'],r['selected_metrics']['ndcg_at_5'],r['selected_metrics']['support_coverage_at_5'],v['core_correct'],v['grounded'],v['citation_valid'],v['note']])
text=f'''# 重排序真实模型对比：重新运行 run-2

日期：2026-10-26（Asia/Shanghai）。A＝原问题＋候选；B＝原问题与直接翻译拼接＋同一候选。

## 本轮结论

在这套公开英文知识快照回归题上，A的原始nDCG@5为{A['raw_ranking']['ndcg_at_5']:.4f}，B为{B['raw_ranking']['ndcg_at_5']:.4f}。B的P@5略高，但首位相关命中和最终关键证据覆盖更低。B的实际padded输入工作量增加{token_change:.1f}%，本机平均墙钟增加{wall_change:.1f}%、CPU增加{cpu_change:.1f}%。优先选择原问题重排作为后续验证默认项；不据此宣称普遍或总体统计显著优势，也未自动改线上。

## 与上一轮隔离及控制变量

- run-1完整保留；本轮只复用冻结的15道题、50个公开英文知识片段、每题相同的30个候选、直接翻译和事先相关性标注。没有借用旧排名、耗时、答案、API用量或成本数据。
- 所有输入在本轮输出前冻结。原中文/混合/阿文问句的直译为英文，英文原问直译为中文；直译仅作为固定输入，本轮没有再次支付翻译调用费。
- 模型BAAI/bge-reranker-v2-m3，revision953dc6f6f85a1b2dbfca4c34a2796e7dde08d41e；CPU4线程、batch4、30秒预算、top5、来源优先2片段、正文12000字符、阈值空、回退和补检关闭。
- 15题×两臂×三轮＝90次新重排，另2次新预热；固定随机题序、AB/BA交替。不重新调用向量检索/RRF，避免候选变化混入重排对比。
- 常驻轻量Docker探针在请求前后采样CPU/内存，避免每次重新fork。测试进程临时防自动休眠；1秒心跳发现超过3秒间断即停；读超时、429或采样中断也停止，已尝试请求不自动补跑。
- 本轮检测：心跳异常{s['environment_validity']['heartbeat_events']}次，计时无效标记{s['environment_validity']['requests_marked_invalid']}次，资源探针失败{s['environment_validity']['probe_failure']}；结束后已解除临时防休眠。
- 11题完整可回答，3题部分缺失，1题虚构配方无资料；相关性0/1/2标注对应无关/有用背景/直接支持核心事实。由Codex对照冻结语料标注与审核，未经独立专家复核。
- 每题每臂重新真实生成一次答案，共30次；相同原问、提示、temperature0、thinking disabled、max_tokens1000；不同于线上thinking设置，但两臂相同。该次级生成不是完整Agent端到端测试。

## 质量结果

排序均值按14道有正例题目等权，重复不当成独立质量样本。虚构配方题无正例，不计算nDCG/MRR，但参与拒答审核。nDCG以同候选池理想顺序归一化；Recall分母为冻结50片段中的全部直接相关片段，不是本次新召回率。

| 指标 | A 原问题 | B 原问题＋直译 |
|---|---:|---:|
| 原始nDCG@5 | {A['raw_ranking']['ndcg_at_5']:.4f} | {B['raw_ranking']['ndcg_at_5']:.4f} |
| 原始P@5（grade2） | {rate(A['raw_ranking']['precision_at_5_direct'])} | {rate(B['raw_ranking']['precision_at_5_direct'])} |
| 原始Recall@5（grade2） | {rate(A['raw_ranking']['recall_at_5_direct'])} | {rate(B['raw_ranking']['recall_at_5_direct'])} |
| 原始MRR | {A['raw_ranking']['mrr_direct']:.4f} | {B['raw_ranking']['mrr_direct']:.4f} |
| 首位直接相关命中 | {rate(A['raw_ranking']['top1_direct'])} | {rate(B['raw_ranking']['top1_direct'])} |
| 证据选择后nDCG@5 | {A['selected_evidence']['ndcg_at_5']:.4f} | {B['selected_evidence']['ndcg_at_5']:.4f} |
| 证据选择后核心支持覆盖 | {rate(A['selected_evidence']['support_coverage_at_5'])} | {rate(B['selected_evidence']['support_coverage_at_5'])} |
| 新答案核心目标达成（含正确指出缺口） | {qa['A']['core_correct']}/15 | {qa['B']['core_correct']}/15 |
| 新答案严格证据忠实 | {qa['A']['grounded']}/15 | {qa['B']['grounded']}/15 |
| 新答案明确附加事实错误数 | {qa['A']['confirmed_factual_errors']}/15 | {qa['B']['confirmed_factual_errors']}/15 |
| 新答案整答严格通过 | {qa['A']['strict_pass']}/15 | {qa['B']['strict_pass']}/15 |

核心目标达成不等于整答事实准确率。答案每臂每题只有一次，生成差异不应全归因于重排。原始nDCG的B−A题目bootstrap95%区间为[{ci[0]:.4f}, {ci[1]:.4f}]，跨零；题集含同题多语言版本，不能当成独立大样本统计显著证明。

本轮逐条问题记录：

{review_notes}

## 成本结果

| 指标 | A | B |
|---|---:|---:|
| 正式请求成功 | {A['successes']}/45 | {B['successes']}/45 |
| 墙钟均值 | {A['wall_seconds_mean']:.3f}秒 | {B['wall_seconds_mean']:.3f}秒 |
| 墙钟中位数 | {A['wall_seconds_median']:.3f}秒 | {B['wall_seconds_median']:.3f}秒 |
| 墙钟P95（45次描述样本） | {A['wall_seconds_p95']:.3f}秒 | {B['wall_seconds_p95']:.3f}秒 |
| CPU均值 | {A['cpu_seconds_mean']:.3f}核秒 | {B['cpu_seconds_mean']:.3f}核秒 |
| 查询token均值 | {A['query_tokens_mean']:.2f} | {B['query_tokens_mean']:.2f} |
| pair token未padding | {A['pair_tokens_unpadded_mean']:.1f} | {B['pair_tokens_unpadded_mean']:.1f} |
| pair token含padding | {A['pair_tokens_padded_mean']:.1f} | {B['pair_tokens_padded_mean']:.1f} |
| 服务RSS峰值采样 | {A['rss_mib_peak_sample']:.1f}MiB | {B['rss_mib_peak_sample']:.1f}MiB |
| cgroup内存峰值采样 | {A['cgroup_memory_mib_peak_sample']:.1f}MiB | {B['cgroup_memory_mib_peak_sample']:.1f}MiB |
| CPU核时/每千次（本机观察外推） | {A['cpu_core_hours_per_1000_requests']:.2f} | {B['cpu_core_hours_per_1000_requests']:.2f} |

两组均30窗口、8批，未触发96 token查询截断。每个查询与30候选分别计算，补充文本的开销被重复到各pair；token工作量是计算代理，不是FLOPs或外部计费token。模型常驻且共享，内存是采样观察，不是两台独立机器的峰值比较。墙钟/CPU结果只代表本机当时条件，不推广为生产SLA。

核秒是所有CPU线程耗时之和；本服务使用4线程，因此约10.7秒墙钟对应约42.7核秒，不表示用户等待42.7秒。本轮与旧轮的环境处理不同，不将跨轮耗时差异称为业务实现提速。

### API费用

本轮实际API调用{s['api_cost']['all']['calls']}次，输入{s['api_cost']['all']['tokens']['input']}、输出{s['api_cost']['all']['tokens']['output']} token，缓存命中{s['api_cost']['all']['tokens']['cached_input']}。按[DeepSeek官方费率](https://api-docs.deepseek.com/quick_start/pricing/)及返回用量，估算本轮费用US${cost['off_peak']:.6f}–{cost['peak']:.6f}（谷/峰费率范围，非账户账单）。本轮冻结直译没有新增调用费；若实际系统已在上游生成翻译，不应重复计费，若为重排另加翻译则需另计。

本地重排没有外部按token费用，但CPU、内存、电费及硬件不为零。本次没有机器单价或功率计，无法把本地计算准确换算为人民币。未计embedding、召回、完整Agent编排和补检成本；绝对重排分数会影响线上weak_score补检，不由本实验推出整链节省。

## 关键例与审核

第14题关键片段74两组都在相同候选池。A排第1并保留；B排第3，前面65/68与74同属ISO文档，来源优先规则挤掉74。分别查看本轮[真实答案与逐题审核](answers.md)，不能用旧轮答案替代本轮生成。其余逐题指标和生成错误均保存在下列文件中。

## 限制与复核文件

这是15题、公开英文知识快照的小型回归实验，非独立留出集；不代表当前整个知识库的跨语言能力。没有修改线上策略、数据库或Git交付。原问重排的低绝对分数与弱相关/补检阈值还需完整链路验证。

- [实验协议](manifest.json)、[冻结标签与候选](cases.json)、[冻结直译](translations-frozen.json)、[公开原文](corpus.json)。
- [90次新重排](rerank-results.jsonl)、[新预热](warmups.jsonl)、[新tokenizer统计](tokenizer-work.json)、[全部指标](summary.json)、[逐题CSV](per-case.csv)。
- [新生成答案](answers.jsonl)、[逐题审核](answer-review.json)、[新API真实用量](api-calls.jsonl)。
- [环境预检](preflight.json)、[运行结束状态](run-state.json)、[逐请求环境有效性](environment-validity.jsonl)、[完整性校验](integrity.json)、[脚本归档](procedures.zip)。

![本轮质量与成本](comparison.png)
'''
(OUT/'report.md').write_bytes(text.encode('utf8'))
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
fig,ax=plt.subplots(1,3,figsize=(12.5,4.2));colors=['#236b55','#d58c37']
for i,(label,key,stage) in enumerate([('Raw nDCG@5','ndcg_at_5','raw_ranking'),('Selected nDCG@5','ndcg_at_5','selected_evidence')]):
    ax[0].bar(i-.18,A[stage][key],.35,color=colors[0],label='Original' if i==0 else None)
    ax[0].bar(i+.18,B[stage][key],.35,color=colors[1],label='Original + translation' if i==0 else None)
ax[0].set_xticks([0,1],['Raw nDCG@5','Selected nDCG@5']);ax[0].set_ylim(0,1);ax[0].set_title('Ranking quality');ax[0].legend(fontsize=8)
for axis,key,title,unit in [(ax[1],'wall_seconds_mean','Mean latency','seconds'),(ax[2],'pair_tokens_padded_mean','Padded model-input tokens','tokens/request')]:
    values=[A[key],B[key]];axis.bar(['A','B'],values,color=colors);axis.set_title(title);axis.set_ylabel(unit)
    for i,value in enumerate(values):axis.text(i,value*1.01,f'{value:.2f}',ha='center')
fig.suptitle('Run-2: frozen candidates, new inference and cost observations');fig.tight_layout();fig.savefig(OUT/'comparison.png',dpi=170);plt.close(fig)
with zipfile.ZipFile(OUT/'procedures.zip','w',zipfile.ZIP_DEFLATED) as archive:
    for name in ('restart.py','experiment.py','pipeline2.py','analyze.py','count_work.py','report2.py'):archive.write(HERE/name,name)
tr=load('translation-review.json')
checks={'cases_frozen':hashlib.sha256((OUT/'cases.json').read_bytes()).hexdigest()==tr['cases_sha256'],
    'translation_frozen':hashlib.sha256((OUT/'translations-frozen.json').read_bytes()).hexdigest()==tr['translations_sha256'],
    'all_90_keys_unique':len({(r['case_id'],r['arm'],r['repeat']) for r in results})==90,
    'same_request_across_repeats':all(len({r['request_sha256'] for r in results if r['case_id']==c['id'] and r['arm']==arm})==1 for c in cases for arm in ('A','B')),
    'same_candidates_both_arms':all(r['candidate_ids']==next(c['candidate_ids'] for c in cases if c['id']==r['case_id']) for r in results),
    'production_source_unchanged':all(hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==value for name,value in manifest['source_fingerprints'].items())}
corpus={c['id']:c for c in load('corpus.json')};translations={r['case_id']:r['translation'] for r in load('translations-frozen.json')}
def expected_request_hash(row):
    case=next(c for c in cases if c['id']==row['case_id'])
    query=case['message'] if row['arm']=='A' else case['message']+' | '+translations[case['id']]
    body={'model':manifest['configuration']['rerank_model'],'query':query,'documents':[{'index':i,'text':corpus[cid]['text']} for i,cid in enumerate(case['candidate_ids'])],'deadline_ms':30000}
    return hashlib.sha256(json.dumps(body,ensure_ascii=False).encode()).hexdigest()
checks['full_payload_only_query_differs']=all(r['request_sha256']==expected_request_hash(r) for r in results)
assert all(checks.values())
save('integrity.json',{'checks':checks,'files_sha256':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in OUT.iterdir() if p.is_file() and p.name!='integrity.json'}})
print(json.dumps({'report':str(OUT/'report.md'),'qa':qa,'wall_increase_pct':wall_change,'cpu_increase_pct':cpu_change,'checks':checks},ensure_ascii=False,indent=2))
