"""New run, frozen inputs; persistent resource probe and fail-fast host checks."""
import ctypes
import hashlib
import json
import os
from pathlib import Path
import queue
import subprocess
import sys
import threading
import time
import types
from datetime import datetime, timezone

ROOT=Path(r'E:\django\dadashop')
OLD=ROOT/'reports/agent-evaluation/2026-10-26-rerank-query-ab/run-1'
OUT=ROOT/'reports/agent-evaluation/2026-10-26-rerank-query-ab/run-2'
SOURCE=Path(__file__).with_name('experiment.py')
os.chdir(ROOT)
sys.path.insert(0,str(ROOT))
source=SOURCE.read_text(encoding='utf8').split('\nmode=sys.argv[1]')[0]
lab=types.ModuleType('rerank_frozen_lab')
exec(compile(source,str(SOURCE),'exec'),lab.__dict__)
lab.OUT=OUT

def stamp():return datetime.now(timezone.utc).isoformat()
def save(name,value):(OUT/name).write_bytes((json.dumps(value,ensure_ascii=False,indent=2)+'\n').encode('utf8'))
def read(name):return json.loads((OUT/name).read_text(encoding='utf8'))
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()

def prepare():
    if OUT.exists():raise RuntimeError('run-2 already exists; preserve it')
    health=lab.requests.get(lab.settings.AI_RERANK_BASE_URL+'/health',timeout=(2,5)).json()
    assert health.get('status')=='ready' and health.get('revision')==lab.settings.AI_RERANK_REVISION
    OUT.mkdir(parents=True)
    names=('cases.json','corpus.json','translations-frozen.json','answer-rubric.json')
    for name in names:(OUT/name).write_bytes((OLD/name).read_bytes())
    config=lab.effective_configuration()
    manifest=read_old('manifest.json')
    manifest.update(started_at=stamp(),configuration=lab.asdict(lab.replace(config,thinking='disabled',telemetry_enabled=False,
        export_enabled=False,rerank_enabled=True,rerank_timeout_ms=30000,rerank_fallback=False,
        retrieval_top_k=5,retrieval_per_document=2,retrieval_context_chars=12000,rerank_min_score=None)),
        serving_config_revision=config.revision,serving_thinking=config.thinking,reranker=health,
        frozen_input_source=str(OLD),frozen_input_sha256={name:digest(OUT/name) for name in names},
        source_fingerprints={name:digest(ROOT/name) for name in manifest['source_fingerprints']})
    manifest['protocol']['translation']='Reuse previously reviewed direct translations as frozen experimental inputs, zero new translation calls; do not reuse any prior ranking, timing, generation, or cost observations.'
    manifest['protocol']['generation']='Generate one fresh actual answer per arm/case from the earliest successful paired repeat; fixed prompt/temperature0/thinking disabled; up to30 calls.'
    manifest['protocol']['budget']='90 new measured rerank calls plus2 new warmups, up to30 new generation calls; zero new translation calls. No serving configuration mutation.'
    manifest['protocol']['monitoring']='One persistent Docker resource-probe process, synchronous snapshots before/after timed inference. Same probe for both arms. Windows keep-awake active only while benchmark process lives; 1s heartbeat logs gaps>3s.'
    manifest['protocol']['environment_failure']='Pause after any heartbeat gap>3s, lost resource sampler, HTTP429 or network ReadTimeout; preserve all attempts and never automatically rerun failed keys. HTTP504 is measured at the unchanged30s budget, not silently retried.'
    save('manifest.json',manifest)
    save('translation-review.json',{'reviewed_before_reranking':True,'all_15_accepted':True,
        'source_review':str(OLD/'translation-review.json'),'reviewer':'Reuse prior reviewed experimental inputs, not prior outcomes',
        'cases_sha256':digest(OUT/'cases.json'),'translations_sha256':digest(OUT/'translations-frozen.json')})
    print(json.dumps({'prepared':str(OUT),'health':health,'config_revision':config.revision},ensure_ascii=False),flush=True)

def read_old(name):return json.loads((OLD/name).read_text(encoding='utf8'))

class Probe:
    def __init__(self):
        code="import sys,json,pathlib,time; p=pathlib.Path('/sys/fs/cgroup');\nfor line in sys.stdin:\n d=dict(x.split() for x in (p/'cpu.stat').read_text().splitlines()); s=dict(x.split(':',1) for x in pathlib.Path('/proc/1/status').read_text().splitlines() if ':' in x); print(json.dumps({'cpu_usec':int(d['usage_usec']),'memory_bytes':int((p/'memory.current').read_text()),'rss_kib':int(s.get('VmRSS','0 kB').split()[0]),'linux_monotonic':time.monotonic()}),flush=True)"
        self.process=subprocess.Popen(['docker','exec','-i',lab.CONTAINER,'python','-u','-c',code],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.DEVNULL)
        self.queue=queue.Queue()
        def reader():
            for line in self.process.stdout:self.queue.put(line)
        threading.Thread(target=reader,daemon=True).start()
        self.failed=False
    def sample(self):
        if self.failed:return {}
        try:
            self.process.stdin.write(b'sample\n');self.process.stdin.flush()
            return json.loads(self.queue.get(timeout=5))
        except Exception as exc:
            self.failed=True
            lab.append('monitoring-errors.jsonl',{'at':stamp(),'error':type(exc).__name__})
            return {}
    def close(self):
        try:self.process.stdin.close()
        except Exception:pass
        try:self.process.wait(timeout=3)
        except subprocess.TimeoutExpired:self.process.terminate()

def run():
    probe=Probe();events=[];stop=threading.Event()
    def heartbeat():
        previous=time.perf_counter()
        while not stop.wait(1):
            current=time.perf_counter();gap=current-previous;previous=current
            if gap>3:
                event={'at':stamp(),'heartbeat_gap_seconds':gap};events.append(event)
                lab.append('environment-events.jsonl',event)
    threading.Thread(target=heartbeat,daemon=True).start()
    keep_awake=bool(ctypes.windll.kernel32.SetThreadExecutionState(0x80000001))
    lab.resources=probe.sample
    previous_keys={(r['case_id'],r['arm'],r['repeat']) for r in lab.rows('rerank-results.jsonl')}
    def checked(case,arm,repeat,warmup=False):
        before_events=len(events)
        if probe.failed or events:raise RuntimeError('Host discontinuity or probe failure; inspection required before resume')
        result=lab.rerank(case,arm,repeat,warmup)
        invalid=probe.failed or len(events)>before_events or result.get('http_status')==429 or result.get('error')=='ReadTimeout'
        lab.append('environment-validity.jsonl',{'case_id':case['id'],'arm':arm,'repeat':repeat,'warmup':warmup,
            'host_timing_valid':not invalid,'keep_awake':keep_awake})
        if invalid:raise RuntimeError('Environment unstable: stopped without rerunning any completed request')
        return result
    try:
        a=probe.sample();time.sleep(1);b=probe.sample()
        if not a or not b:raise RuntimeError('Resource probe unavailable')
        idle=(b['cpu_usec']-a['cpu_usec'])/1e6
        save('preflight.json',{'at':stamp(),'keep_awake':keep_awake,'idle_interval_cpu_core_seconds':idle,
             'persistent_resource_probe':True,'old_results_reused':False})
        if idle>0.6:raise RuntimeError('Reranker already busy; keep experiment untouched and retry preflight later')
        if not lab.rows('warmups.jsonl'):
            checked(lab.cases[0],'A',-1,True);checked(lab.cases[0],'B',-1,True)
        for repeat in range(3):
            for case_id in lab.manifest['case_order']:
                case=next(c for c in lab.cases if c['id']==case_id)
                for arm in (('A','B') if (case_id+repeat)%2 else ('B','A')):
                    if (case_id,arm,repeat) not in previous_keys:checked(case,arm,repeat)
    finally:
        stop.set();probe.close()
        ctypes.windll.kernel32.SetThreadExecutionState(0x80000000)
        save('run-state.json',{'at':stamp(),'measured_requests':len(lab.rows('rerank-results.jsonl')),
             'environment_events':events,'probe_failed':probe.failed,'keep_awake_released':True})

mode=sys.argv[1]
if mode=='prepare':prepare()
else:
    lab.manifest=read('manifest.json');lab.config=lab.AgentConfig(**lab.manifest['configuration'])
    lab.cases=read('cases.json');corpus=read('corpus.json')
    lab.chunks={c['id']:{'chunk_id':c['id'],'document_id':c['document_id'],'text':c['text'],
        'metadata':c['metadata'],'source_title':c['document__title'],'source_reference':c['document__source_reference']} for c in corpus}
    if mode=='run':run()
    elif mode=='answers':
        ctypes.windll.kernel32.SetThreadExecutionState(0x80000001)
        try:lab.answers()
        finally:ctypes.windll.kernel32.SetThreadExecutionState(0x80000000)
