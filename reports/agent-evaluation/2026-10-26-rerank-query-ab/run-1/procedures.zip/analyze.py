import json
import math
from pathlib import Path
import random
import statistics

ROOT=Path(r'E:\django\dadashop')
OUT=ROOT/'reports/agent-evaluation/2026-10-26-rerank-query-ab/run-1'
def load(name):return json.loads((OUT/name).read_text(encoding='utf8'))
def rows(name):return [json.loads(x) for x in (OUT/name).read_text(encoding='utf8').splitlines()]
def mean(values):
    values=[v for v in values if v is not None]
    return statistics.mean(values) if values else None
def percentile(values,p):
    values=sorted(values)
    k=(len(values)-1)*p
    a,b=math.floor(k),math.ceil(k)
    return values[a]+(values[b]-values[a])*(k-a)
def interval(values):
    rng=random.Random(20261026)
    samples=[mean(rng.choices(values,k=len(values))) for _ in range(10000)]
    return [percentile(samples,.025),percentile(samples,.975)]
manifest=load('manifest.json'); cases=load('cases.json');results=rows('rerank-results.jsonl')
assert len(results)==90, 'Do not summarize incomplete experiment as complete'
success=[r for r in results if r['status']=='success']
paired_keys={(r['case_id'],r['repeat']) for r in success
    if all(any(s['case_id']==r['case_id'] and s['repeat']==r['repeat'] and s['arm']==arm for s in success) for arm in ('A','B'))}
paired_success=[r for r in success if (r['case_id'],r['repeat']) in paired_keys]
metric_names=['ndcg_at_5','precision_at_5_direct','recall_at_5_direct','mrr_direct','top1_direct','support_coverage_at_5','all_support_at_5']
summary={'measured_calls':len(results),'successes':len(success),'failures':[{'case_id':r['case_id'],'arm':r['arm'],'repeat':r['repeat'],'error':r.get('error')} for r in results if r['status']!='success'],
         'quality_unit':'14 questions with positive labels; 3 repeats each; repeats are NOT 42 independent quality samples; case13 no-evidence excluded from ranking-quality averages',
         'arms':{},'paired_quality':{},'paired_latency':{},'cases':[]}
summary['complete_successful_pairs']=len(paired_keys)
warmups=rows('warmups.jsonl')
summary['experiment_local_cost']={'measured_request_wall_seconds':sum(r['wall_seconds'] for r in results),
    'measured_cpu_core_seconds':sum(r.get('cpu_seconds',0) for r in results),
    'cpu_samples_missing':sum('cpu_seconds' not in r for r in results),
    'warmup_requests':len(warmups),'warmup_wall_seconds':sum(r['wall_seconds'] for r in warmups),
    'warmup_cpu_core_seconds':sum(r['cpu_seconds'] for r in warmups),
    'note':'Warmups excluded from paired latency/quality averages but retained in total experimental compute cost; cgroup CPU includes probes and any concurrent service work.'}
summary['failure_policy']='No automatic retry or replacement. Availability and wall/CPU costs include all measured attempts; quality uses only paired successes and reports missing pairs.'
work={(r['case_id'],r['arm']):r for r in load('tokenizer-work.json')}
for arm in ('A','B'):
    attempts=[r for r in results if r['arm']==arm]
    rr=[r for r in paired_success if r['arm']==arm]
    arm_work=[work[(c['id'],arm)] for c in cases]
    summary['arms'][arm]={
        'requests':len(attempts),'successes':sum(r['status']=='success' for r in attempts),'paired_successes':len(rr),
        'raw_ranking':{key:mean([r['metrics'][key] for r in rr]) for key in metric_names},
        'selected_evidence':{key:mean([r['selected_metrics'][key] for r in rr]) for key in metric_names},
        'wall_seconds_mean':mean([r['wall_seconds'] for r in attempts]),
        'wall_seconds_median':statistics.median([r['wall_seconds'] for r in attempts]),
        'wall_seconds_p95':percentile([r['wall_seconds'] for r in attempts],.95),
        'server_seconds_mean':mean([r['server_seconds'] for r in rr]),
        'cpu_seconds_mean':mean([r.get('cpu_seconds') for r in attempts]),
        'cpu_samples_available':sum('cpu_seconds' in r for r in attempts),
        'paired_success_wall_seconds_mean':mean([r['wall_seconds'] for r in rr]),
        'paired_success_cpu_seconds_mean':mean([r.get('cpu_seconds') for r in rr]),
        'rss_mib_peak_sample':max(r['resources_after']['rss_kib']/1024 for r in attempts if r.get('resources_after')),
        'cgroup_memory_mib_peak_sample':max(r['resources_after']['memory_bytes']/1024**2 for r in attempts if r.get('resources_after')),
        'query_tokens_mean':mean([r['effective_query_tokens'] for r in arm_work]),
        'query_truncations':sum(r['query_truncated'] for r in arm_work),
        'pair_tokens_unpadded_mean':mean([r['pair_tokens_unpadded'] for r in arm_work]),
        'pair_tokens_padded_mean':mean([r['pair_tokens_padded'] for r in arm_work]),
        'windows_mean':mean([r['windows'] for r in arm_work]),
        'cpu_core_hours_per_1000_requests':mean([r.get('cpu_seconds') for r in attempts])*1000/3600,
    }
for case in cases:
    record={'case_id':case['id'],'question':case['message'],'scene':case['scene'],'arms':{}}
    for arm in ('A','B'):
        rr=[r for r in paired_success if r['case_id']==case['id'] and r['arm']==arm]
        attempts=[r for r in results if r['case_id']==case['id'] and r['arm']==arm]
        record['arms'][arm]={'ranking_metrics':{k:mean([r['metrics'][k] for r in rr]) for k in metric_names},
            'selected_metrics':{k:mean([r['selected_metrics'][k] for r in rr]) for k in metric_names},
            'wall_seconds':mean([r['wall_seconds'] for r in attempts]),'cpu_seconds':mean([r.get('cpu_seconds') for r in attempts]),
            'top5_rankings':[[x['chunk_id'] for x in r['ranking'][:5]] for r in rr],
            'selected_ids':[[x['chunk_id'] for x in r['selected']] for r in rr],
            'deterministic_top5_across_repeats':len({tuple(x['chunk_id'] for x in r['ranking'][:5]) for r in rr})==1,
            'deterministic_full_ranking_across_repeats':len({tuple(x['chunk_id'] for x in r['ranking']) for r in rr})==1}
    summary['cases'].append(record)
for arm in ('A','B'):
    summary['arms'][arm]['raw_ranking']={key:mean([c['arms'][arm]['ranking_metrics'][key] for c in summary['cases']]) for key in metric_names}
    summary['arms'][arm]['selected_evidence']={key:mean([c['arms'][arm]['selected_metrics'][key] for c in summary['cases']]) for key in metric_names}
summary['rankable_questions_with_complete_pairs']=sum(c['arms']['A']['ranking_metrics']['ndcg_at_5'] is not None for c in summary['cases'])
for key in metric_names:
    for stage in ('ranking_metrics','selected_metrics'):
        deltas=[c['arms']['B'][stage][key]-c['arms']['A'][stage][key] for c in summary['cases'] if c['arms']['A'][stage][key] is not None and c['arms']['B'][stage][key] is not None]
        summary['paired_quality'][stage+'.'+key]={'mean_delta_B_minus_A':mean(deltas),'wins':sum(d>1e-10 for d in deltas),'ties':sum(abs(d)<=1e-10 for d in deltas),'losses':sum(d< -1e-10 for d in deltas),'question_bootstrap_95ci':interval(deltas)}
for key in ('wall_seconds','cpu_seconds'):
    deltas=[c['arms']['B'][key]-c['arms']['A'][key] for c in summary['cases']]
    summary['paired_latency'][key]={'mean_delta_B_minus_A':mean(deltas),'question_bootstrap_95ci':interval(deltas)}
    summary['arms']['B'][key+'_increase_pct']=100*summary['paired_latency'][key]['mean_delta_B_minus_A']/mean([c['arms']['A'][key] for c in summary['cases']])
# Corpus families are paraphrase-correlated. Also report a family bootstrap.
families=[[1,2,3,4],[5,6,7],[8],[9],[10],[11],[12],[14],[15]]
for stage in ('ranking_metrics','selected_metrics'):
    deltas=[]
    for family in families:
        group=[c for c in summary['cases'] if c['case_id'] in family and c['arms']['A'][stage]['ndcg_at_5'] is not None and c['arms']['B'][stage]['ndcg_at_5'] is not None]
        if group: deltas.append(mean([c['arms']['B'][stage]['ndcg_at_5']-c['arms']['A'][stage]['ndcg_at_5'] for c in group]))
    summary['paired_quality'][stage+'.ndcg_at_5']['family_mean_delta']=mean(deltas)
    summary['paired_quality'][stage+'.ndcg_at_5']['family_bootstrap_95ci']=interval(deltas)
def token_counts(usage):
    hit=usage.get('prompt_cache_hit_tokens',(usage.get('prompt_tokens_details') or {}).get('cached_tokens',0)) or 0
    return {'input':usage['prompt_tokens'],'output':usage['completion_tokens'],'cached_input':hit,'uncached_input':usage['prompt_tokens']-hit}
def cost(usage,rate):
    t=token_counts(usage)
    return (t['cached_input']*rate['cached_input']+t['uncached_input']*rate['uncached_input']+t['output']*rate['output'])/1e6
calls=rows('api-calls.jsonl');answers=rows('answers.jsonl');translations=load('translations-frozen.json')
api={}
for kind in ('translation','translation_revision','answer','all'):
    selected=calls if kind=='all' else [r for r in calls if r['kind']==kind]
    api[kind]={'calls':len(selected),'seconds_total':sum(r['seconds'] for r in selected),
        'tokens':{key:sum(token_counts(r['usage'])[key] for r in selected) for key in ('input','output','cached_input','uncached_input')},
        'estimated_usd_range':{period:sum(cost(r['usage'],rate) for r in selected) for period,rate in manifest['prices_usd_per_million'].items()}}
for arm in ('A','B'):
    selected=[r for r in answers if r['arm']==arm and r['status']=='success']
    api['answers_'+arm]={'calls':len(selected),'seconds_mean':mean([r['seconds'] for r in selected]),
        'input_tokens':sum(r['usage']['prompt_tokens'] for r in selected),'output_tokens':sum(r['usage']['completion_tokens'] for r in selected),
        'estimated_usd_range':{period:sum(cost(r['usage'],rate) for r in selected) for period,rate in manifest['prices_usd_per_million'].items()}}
api['accepted_translation_serving_cost']={'calls':len(translations),'seconds_mean':mean([r['seconds'] for r in translations]),
    'estimated_usd_range':{period:sum(cost(r['usage'],rate) for r in translations) for period,rate in manifest['prices_usd_per_million'].items()}}
api['billing_note']='Published official price estimate from returned usage, not invoice; report off-peak/peak range, excludes electricity/depreciation and no assumed local per-token API charge. Actual experiment includes discarded translation revision cost; serving B needs no extra translation call if upstream translation already exists.'
api['standardized_uncached_answer_cost']={arm:{period:sum((r['usage']['prompt_tokens']*rate['uncached_input']+r['usage']['completion_tokens']*rate['output'])/1e6 for r in answers if r['arm']==arm and r['status']=='success') for period,rate in manifest['prices_usd_per_million'].items()} for arm in ('A','B')}
summary['api_cost']=api
(OUT/'summary.json').write_bytes((json.dumps(summary,ensure_ascii=False,indent=2)+'\n').encode('utf8'))
print(json.dumps({'arms':summary['arms'],'paired_ndcg':{k:v for k,v in summary['paired_quality'].items() if 'ndcg' in k},'api_cost':api},ensure_ascii=False,indent=2))
