"""Real paired reranker experiment on frozen public candidates; no serving writes."""
import hashlib
import json
import math
import os
from pathlib import Path
import random
import statistics
import subprocess
import sys
import time
from datetime import datetime, timezone
from dataclasses import asdict, replace

ROOT = Path(r'E:\django\dadashop')
OUT = ROOT / 'reports/agent-evaluation/2026-10-26-rerank-query-ab/run-1'
ARCHIVE = ROOT / 'reports/archive/2026-10-16/agent-evaluation/2026-10-16-rag-rewrite/paired-run-1'
CONTAINER = 'dadashop-reranker-reranker-1'
os.chdir(ROOT)
sys.path.insert(0, str(ROOT))
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'tea_saas.settings')
import django
django.setup()
import requests
from django.conf import settings
from openai import OpenAI
from support_ai.configuration import effective_configuration, AgentConfig
from support_ai.retrieval import select_evidence
from support_ai.query_rewrite import coverage_order

def now():
    return datetime.now(timezone.utc).isoformat()

def save(name, value):
    (OUT / name).write_bytes((json.dumps(value, ensure_ascii=False, indent=2) + '\n').encode('utf8'))

def append(name, value):
    with (OUT / name).open('a', encoding='utf8') as handle:
        handle.write(json.dumps(value, ensure_ascii=False) + '\n')

def rows(name):
    path = OUT / name
    return [json.loads(line) for line in path.read_text(encoding='utf8').splitlines()] if path.exists() else []

def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def metrics(ids, case):
    grades = case['grades']
    relevant = {int(k) for k, v in grades.items() if v == 2}
    gains = [grades.get(str(i), 0) for i in ids]
    ideal = sorted([grades.get(str(i), 0) for i in case['candidate_ids']], reverse=True)
    dcg = sum((2 ** g - 1) / math.log2(i + 2) for i, g in enumerate(gains[:5]))
    idcg = sum((2 ** g - 1) / math.log2(i + 2) for i, g in enumerate(ideal[:5]))
    rr = next((1 / (i + 1) for i, g in enumerate(gains) if g == 2), 0) if relevant else None
    groups = case['support_groups']
    return {'ndcg_at_5': dcg / idcg if idcg else None,
            'precision_at_5_direct': sum(g == 2 for g in gains[:5]) / 5 if relevant else None,
            'recall_at_5_direct': len(set(ids[:5]) & relevant) / len(relevant) if relevant else None,
            'mrr_direct': rr,
            'top1_direct': int(bool(gains) and gains[0] == 2) if relevant else None,
            'support_coverage_at_5': sum(bool(set(ids[:5]) & set(g)) for g in groups) / len(groups) if groups else None,
            'all_support_at_5': int(all(set(ids[:5]) & set(g) for g in groups)) if groups else None}

def resources():
    code = "import json,pathlib; p=pathlib.Path('/sys/fs/cgroup'); cpu=dict(x.split() for x in (p/'cpu.stat').read_text().splitlines()); s=dict(x.split(':',1) for x in pathlib.Path('/proc/1/status').read_text().splitlines() if ':' in x); print(json.dumps({'cpu_usec':int(cpu['usage_usec']),'memory_bytes':int((p/'memory.current').read_text()),'rss_kib':int(s.get('VmRSS','0 kB').split()[0])}))"
    try:
        result = subprocess.run(['docker', 'exec', CONTAINER, 'python', '-c', code], capture_output=True, timeout=5)
        return json.loads(result.stdout) if result.returncode == 0 else {}
    except (subprocess.TimeoutExpired, ValueError, OSError) as exc:
        append('monitoring-errors.jsonl',{'at':now(),'error':type(exc).__name__,'phase':'resource_probe'})
        return {}

def api_call(kind, case, messages, max_tokens):
    client = OpenAI(api_key=settings.SUPPORT_API_KEY, base_url=settings.SUPPORT_BASE_URL,
                    timeout=90, max_retries=0)
    started = time.perf_counter()
    stamp = now()
    reply = client.chat.completions.create(model=manifest['configuration']['model'], messages=messages,
        temperature=0, max_tokens=max_tokens, extra_body={'thinking': {'type': 'disabled'}},
        **({'response_format': {'type': 'json_object'}} if kind == 'translation' else {}))
    seconds = time.perf_counter() - started
    result = {'kind':kind, 'case_id':case['id'], 'started_at':stamp, 'seconds':seconds,
              'model':reply.model, 'usage':reply.usage.model_dump() if reply.usage else None,
              'finish_reason':reply.choices[0].finish_reason, 'text':reply.choices[0].message.content,
              'request_sha256':hashlib.sha256(json.dumps(messages, ensure_ascii=False).encode()).hexdigest()}
    append('api-calls.jsonl', result)
    return result

def prepare():
    if OUT.exists():
        raise RuntimeError('Preserve existing experiment directory')
    OUT.mkdir(parents=True)
    config = effective_configuration()
    health = requests.get(settings.AI_RERANK_BASE_URL + '/health', timeout=5).json()
    assert health.get('status') == 'ready' and health.get('revision') == settings.AI_RERANK_REVISION
    corpus = json.loads((ARCHIVE / 'corpus.json').read_text(encoding='utf8'))
    raw_cases = json.loads((ROOT / 'support_ai/evaluation/rag_rewrite_cases.json').read_text(encoding='utf8'))
    recorded = [json.loads(x) for x in (ARCHIVE / 'results.jsonl').read_text(encoding='utf8').splitlines()]
    # Exhaustive grades assigned BEFORE observing either experimental arm.
    label_sets = {
        1:([62,64,65,81],[63,75,78]), 2:([62,64,65,81],[63,75,78]),
        3:([62,64,65,81],[63,75,78]), 4:([62,64,65,81],[63,75,78]),
        5:([59],[]), 6:([59],[]), 7:([59],[]), 8:([59,60],[]),
        9:([62,64,69,81],[63,76]), 10:([64,69,76,81],[62,63,75]),
        11:([79],[74,77,80]), 12:([59],[]), 13:([],[]),
        14:([74],[]), 15:([62,64,65,66,81],[63,75,78])}
    cases = []
    for case in raw_cases:
        source = next(r for r in recorded if r['case_id'] == case['id'] and r['arm'] == 'single_query')
        assert all(route['owner_id'] is None for route in source['vector_routes'])
        pool = source['vector_routes'][0]['chunk_ids']
        direct, background = label_sets[case['id']]
        grades = {str(c['id']): 2 if c['id'] in direct else 1 if c['id'] in background else 0 for c in corpus}
        cases.append({**case, 'candidate_ids':pool, 'grades':grades,
                      'target_language':'Chinese' if case['id'] in (2,6,10) else 'English'})
    protocol = {'design':'15 fixed public regression cases; A=original; B=original | direct translation; 3 paired rounds; case order fixed shuffled seed 20261026; AB/BA alternates by case and round',
        'candidate_policy':'Identical ordered 30-candidate pool per case from archived public single-query recall; no retrieval calls, no gold injection; identical pool across all arms and repeats',
        'labels':'Pre-output exhaustive 0/1/2 grades across 50 frozen chunks: 2 directly supports a requested core fact, 1 useful background, 0 irrelevant; agent annotated against corpus, no independent expert adjudication; historical support groups separately preserved',
        'isolated_variable':'Only reranker query string differs; same weights, tokenizer, server, candidate order, timeout=30000ms, source diversity=2, top_k=5, char_budget=12000; fallback/retry OFF in experiment',
        'generation':'One generation per arm/case from first successful repeat; same original question and prompt, temperature=0, thinking disabled, max_tokens=1000. Paired order alternates. Not full Agent workflow.',
        'translation':'One actual API call per question, frozen before reranking; direct faithful translation only; zh/mixed/ar to en, en to zh; explicit translation review before running arms',
        'cost':'Per-request wall/server seconds, cgroup CPU seconds and RSS/cgroup memory samples; exact reranker tokenizer workload collected separately; actual provider usage for translation/generation, estimated USD off-peak/peak range, excludes hardware/electricity and unpriced failures',
        'budget':'90 measured rerank calls + 2 warmups; 15 translation calls + 30 answer calls; no customer identity/history, DB writes, telemetry export or live configuration mutation',
        'limits':'Small existing regression set, English public corpus snapshot from 2026-10-16; not current-corpus recall test, not independent held-out evaluation, not universal multilingual accuracy'}
    data = {'started_at':now(), 'source_head':subprocess.check_output(['git','rev-parse','HEAD']).decode().strip(),
            'configuration':asdict(replace(config, thinking='disabled',telemetry_enabled=False,export_enabled=False,
                rerank_enabled=True,rerank_timeout_ms=30000,rerank_fallback=False,retrieval_top_k=5,
                retrieval_per_document=2,retrieval_context_chars=12000,rerank_min_score=None)),
            'serving_config_revision':config.revision,'serving_thinking':config.thinking,'reranker':health,
            'protocol':protocol,'case_order':random.Random(20261026).sample(list(range(1,16)),15),
            'source_fingerprints':{name:digest(ROOT/name) for name in ('support_ai/retrieval.py','support_ai/query_rewrite.py','ai_storage/reranking.py','deploy/reranker/server.py','support_ai/evaluation/rag_rewrite_cases.json')},
            'prices_usd_per_million':{'off_peak':{'cached_input':0.003,'uncached_input':0.15,'output':0.6},'peak':{'cached_input':0.006,'uncached_input':0.3,'output':1.2}},
            'pricing_source':'https://api-docs.deepseek.com/quick_start/pricing/','pricing_read_on':'2026-10-26'}
    save('manifest.json', data)
    save('corpus.json', corpus)
    save('cases.json', cases)
    print(json.dumps({'prepared':str(OUT),'cases':len(cases),'corpus':len(corpus),'protocol':protocol},ensure_ascii=False),flush=True)

def translate():
    existing = {r['case_id'] for r in rows('translations.jsonl')}
    for case in cases:
        if case['id'] in existing: continue
        messages = [{'role':'system','content':'You are a faithful translator of tea knowledge questions. Return JSON with exactly one key translation. Translate directly into the requested language. Preserve the full question, numbers, named entities, comparisons, uncertainty and exclusions. Do not answer, explain, add search keywords or broaden the question. Terminology: black tea=红茶=hongcha; dark tea=黑茶=heicha; fixation=杀青; KSA=Saudi Arabia; UAE=United Arab Emirates. A fictional name must stay fictional, do not invent a real product.'},
            {'role':'user','content':json.dumps({'target_language':case['target_language'],'question':case['message']},ensure_ascii=False)}]
        result = api_call('translation',case,messages,400)
        translation = json.loads(result['text'])['translation'].strip()
        assert translation and translation != case['message'] and result['finish_reason']=='stop'
        row = {'case_id':case['id'],'original':case['message'],'target_language':case['target_language'],
               'translation':translation,'seconds':result['seconds'],'usage':result['usage']}
        append('translations.jsonl', row)
        print(json.dumps(row,ensure_ascii=False),flush=True)

def rerank(case, arm, repeat, warmup=False):
    translation = next(r['translation'] for r in json.loads((OUT/'translations-frozen.json').read_text(encoding='utf8')) if r['case_id']==case['id'])
    query = case['message'] if arm=='A' else case['message'] + ' | ' + translation
    candidates = [dict(chunks[i],vector_rank=n+1) for n,i in enumerate(case['candidate_ids'])]
    body = {'model':config.rerank_model,'query':query,'documents':[{'index':i,'text':c['text']} for i,c in enumerate(candidates)],'deadline_ms':30000}
    before = resources()
    start = time.perf_counter()
    row = {'case_id':case['id'],'arm':arm,'repeat':repeat,'warmup':warmup,'started_at':now(),
           'query':query,'candidate_ids':case['candidate_ids'],'request_sha256':hashlib.sha256(json.dumps(body,ensure_ascii=False).encode()).hexdigest()}
    try:
        response = requests.post(settings.AI_RERANK_BASE_URL+'/rerank',json=body,timeout=(2,40))
        row['wall_seconds'] = time.perf_counter()-start
        row['http_status'] = response.status_code
        if response.status_code != 200:
            row['status']='failed'
            row['error']='HTTP '+str(response.status_code)
        else:
            data = response.json()
            assert data['model']==config.rerank_model and data['revision']==manifest['reranker']['revision']
            seen=set();ranked=[]
            for result in data['results']:
                i, value, excerpt = result['index'], result['score'], result['excerpt']
                assert type(i) is int and 0<=i<len(candidates) and i not in seen
                assert math.isfinite(value) and 0<=value<=1 and excerpt and excerpt in candidates[i]['text']
                seen.add(i)
                ranked.append(dict(candidates[i],rerank_score=value,evidence_excerpt=excerpt))
            assert len(seen)==len(candidates)
            ranked.sort(key=lambda r:(-r['rerank_score'],r['vector_rank']))
            ranked=[dict(r,rerank_rank=i+1) for i,r in enumerate(ranked)]
            selected=select_evidence(coverage_order(case['message'],ranked),config)
            pure_ids=[r['chunk_id'] for r in ranked]
            selected_ids=[r['chunk_id'] for r in selected]
            row.update(status='success',server_seconds=data['duration_ms']/1000,windows=data['windows'],
                ranking=[{'chunk_id':r['chunk_id'],'score':r['rerank_score'],'rank':r['rerank_rank'],'excerpt':r['evidence_excerpt']} for r in ranked],
                selected=selected,metrics=metrics(pure_ids,case),selected_metrics=metrics(selected_ids,case))
    except Exception as exc:
        row.update(status='failed',error=type(exc).__name__,wall_seconds=time.perf_counter()-start)
    after = resources()
    row['resources_before'],row['resources_after']=before,after
    if before and after: row['cpu_seconds']=(after['cpu_usec']-before['cpu_usec'])/1e6
    append('warmups.jsonl' if warmup else 'rerank-results.jsonl',row)
    print(json.dumps({k:row.get(k) for k in ('case_id','arm','repeat','status','wall_seconds','server_seconds','cpu_seconds','error')},ensure_ascii=False),flush=True)
    return row

def run():
    assert (OUT/'translation-review.json').exists(), 'Translations must be reviewed before arm execution'
    done={(r['case_id'],r['arm'],r['repeat']) for r in rows('rerank-results.jsonl')}
    if not rows('warmups.jsonl'):
        rerank(cases[0],'A',-1,True)
        rerank(cases[0],'B',-1,True)
    for repeat in range(3):
        for case_id in manifest['case_order']:
            case=next(c for c in cases if c['id']==case_id)
            for arm in (('A','B') if (case_id+repeat)%2 else ('B','A')):
                if (case_id,arm,repeat) not in done:
                    rerank(case,arm,repeat)

def answers():
    done={(r['case_id'],r['arm']) for r in rows('answers.jsonl')}
    observed=rows('rerank-results.jsonl')
    prompt='你是茶叶知识助手。仅依据本次提供的证据回答原问题，用中文，简洁但覆盖全部可回答的核心点。事实陈述用[片段ID]引用。不要补充证据外事实，不要把进口或消费预测当成饮茶习俗。资料不足时明确具体缺口；没有相关证据时拒绝编造。不要推荐商品。控制在350字以内。'
    for case_id in manifest['case_order']:
        case=next(c for c in cases if c['id']==case_id)
        for arm in (('A','B') if case_id%2 else ('B','A')):
            if (case_id,arm) in done:continue
            complete_repeats=[rep for rep in range(3) if all(any(r['case_id']==case_id and r['arm']==a and r['repeat']==rep and r['status']=='success' for r in observed) for a in ('A','B'))]
            result=next((r for r in observed if complete_repeats and r['case_id']==case_id and r['arm']==arm and r['repeat']==complete_repeats[0] and r['status']=='success'),None)
            if not result:
                append('answers.jsonl',{'case_id':case_id,'arm':arm,'status':'not_generated_rerank_failed'})
                continue
            evidence=[{'chunk_id':r['chunk_id'],'text':r['text']} for r in result['selected']]
            messages=[{'role':'system','content':prompt},{'role':'user','content':json.dumps({'question':case['message'],'evidence':evidence},ensure_ascii=False)}]
            response=api_call('answer',case,messages,1000)
            row={'case_id':case_id,'arm':arm,'status':'success','source_repeat':result['repeat'],'selected_ids':[r['chunk_id'] for r in evidence],**response}
            append('answers.jsonl',row)
            print(json.dumps({'case_id':case_id,'arm':arm,'seconds':response['seconds'],'text':response['text']},ensure_ascii=False),flush=True)

mode=sys.argv[1]
if mode=='prepare':
    prepare()
else:
    manifest=json.loads((OUT/'manifest.json').read_text(encoding='utf8'))
    cases=json.loads((OUT/'cases.json').read_text(encoding='utf8'))
    corpus=json.loads((OUT/'corpus.json').read_text(encoding='utf8'))
    chunks={c['id']:{'chunk_id':c['id'],'document_id':c['document_id'],'text':c['text'],
        'metadata':c['metadata'],'source_title':c['document__title'],'source_reference':c['document__source_reference']} for c in corpus}
    config=AgentConfig(**manifest['configuration'])
    if mode=='translate': translate()
    elif mode=='revise_translation_9':
        case=next(c for c in cases if c['id']==9)
        result=api_call('translation_revision',case,[{'role':'system','content':'Translate directly into English. Return JSON with exactly one key translation. No parenthetical gloss, pinyin, extra synonyms, expansion or answer. 红茶=black tea, 黑茶=dark tea.'},{'role':'user','content':case['message']}],200)
        revised=json.loads(result['text'])['translation']
        frozen=rows('translations.jsonl')
        next(r for r in frozen if r['case_id']==9)['translation']=revised
        save('translations-frozen.json',frozen)
        print(revised,flush=True)
    elif mode=='run': run()
    elif mode=='answers': answers()
