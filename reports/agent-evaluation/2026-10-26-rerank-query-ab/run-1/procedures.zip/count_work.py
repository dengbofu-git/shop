"""Count actual deployed tokenizer work after timed inference, no model forward."""
import json
from pathlib import Path
import subprocess

ROOT = Path(r'E:\django\dadashop')
OUT = ROOT/'reports/agent-evaluation/2026-10-26-rerank-query-ab/run-1'
cases=json.loads((OUT/'cases.json').read_text(encoding='utf8'))
corpus={c['id']:c for c in json.loads((OUT/'corpus.json').read_text(encoding='utf8'))}
translations={r['case_id']:r['translation'] for r in json.loads((OUT/'translations-frozen.json').read_text(encoding='utf8'))}
payload=[]
for c in cases:
    for arm in ('A','B'):
        payload.append({'case_id':c['id'],'arm':arm,
            'query':c['message'] if arm=='A' else c['message']+' | '+translations[c['id']],
            'documents':[corpus[i]['text'] for i in c['candidate_ids']]})
code=r'''
import sys,json,os,math
from transformers import AutoTokenizer
tokenizer=AutoTokenizer.from_pretrained(os.getenv('RERANK_MODEL'),revision=os.getenv('RERANK_REVISION'),trust_remote_code=False,local_files_only=True)
payload=json.load(sys.stdin)
result=[]
for row in payload:
    original=tokenizer.encode(row['query'],add_special_tokens=False)
    query=tokenizer.decode(original[:96],skip_special_tokens=True)
    qlen=len(tokenizer.encode(query,add_special_tokens=False))
    room=512-qlen-4
    windows=[]
    for doc in row['documents']:
        offsets=tokenizer(doc,add_special_tokens=False,return_offsets_mapping=True)['offset_mapping']
        starts=list(range(0,max(1,len(offsets)-room+1),room-64))
        if starts and starts[-1]+room<len(offsets):starts.append(starts[-1]+room-64)
        for start in starts:
            part=offsets[start:start+room]
            windows.append(doc[part[0][0]:part[-1][1]] if part else doc)
    batch_size=max(1,min(16,int(os.getenv('RERANK_BATCH_SIZE','4'))))
    actual_tokens=padded_tokens=0
    for pos in range(0,len(windows),batch_size):
        batch=tokenizer([[query,t] for t in windows[pos:pos+batch_size]],padding=True,truncation='only_second',max_length=512)
        actual_tokens+=sum(sum(mask) for mask in batch['attention_mask'])
        padded_tokens+=sum(len(ids) for ids in batch['input_ids'])
    result.append({'case_id':row['case_id'],'arm':row['arm'],'raw_query_tokens':len(original),'effective_query_tokens':qlen,
        'query_truncated':len(original)>96,'windows':len(windows),'model_batches':math.ceil(len(windows)/batch_size),
        'pair_tokens_unpadded':actual_tokens,'pair_tokens_padded':padded_tokens,
        'raw_query_utf8_bytes':len(row['query'].encode('utf8'))})
print(json.dumps(result))
'''
result=subprocess.run(['docker','exec','-i','dadashop-reranker-reranker-1','python','-c',code],input=json.dumps(payload).encode('utf8'),capture_output=True,timeout=120)
if result.returncode:
    raise RuntimeError(result.stderr.decode('utf8','replace')[-1000:])
work=json.loads(result.stdout)
(OUT/'tokenizer-work.json').write_bytes((json.dumps(work,ensure_ascii=False,indent=2)+'\n').encode('utf8'))
print(json.dumps({'counted':len(work),'query_truncations':sum(r['query_truncated'] for r in work)},ensure_ascii=False))
